require(data.table)
require(terra)

adm0_path        <- "E:/CSOSA/Dropbox/VAVILOV_2.0/DATA/Input_data/adm0/adm0_Latam.shp"
template_path    <- "//catalogue/MultifLandscapesA1706/1.Data/RAW/Input_data/Raster target region/2_5min/target_region.tif"
sf::sf_use_s2(FALSE)
tmpl   <- terra::rast(template_path)
tmpl[which(tmpl[] != 0)] <- 1
tmpl[which(tmpl[] == 0)] <- 1
adm0_w <- sf::read_sf(adm0_path)
#fixing topology
adm0_w <- sf::st_make_valid(adm0_w)
spList <- readxl::read_xlsx("E:/CSOSA/Dropbox/VAVILOV_2.0/Results/SUMMARY_FILES/PROJECT_STATUS.xlsx","Concave_missing2")
spList <- spList$species
occs_path        <- "E:/CSOSA/Dropbox/VAVILOV_2.0/Results/occurrences/GBIF_joined_FINAL_20260317_spList_filtered.csv"
#missing species
# write.csv(spList,"E:/CSOSA/Dropbox/VAVILOV_2.0/Results/sp_concave_hull_fixed.csv")


conversion_table <-
  readxl::read_xlsx(
    "E:/CSOSA/Dropbox/VAVILOV_2.0/Results/SUMMARY_FILES/PROJECT_STATUS.xlsx",
    "Hoja1"
  )

conversion_table2 <- conversion_table[conversion_table$species_from_source %in% spList,]
# sp <- "Lycium brevipes"

# ?????? Directories ?????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????
result_dir      <- "//catalogue/MultifLandscapesA1706/1.Data/Results"
# result_dir      <- "E:/CSOSA/Dropbox/VAVILOV_2.0/DATA/DATABASES/results"
occs_dir <- "//catalogue/MultifLandscapesA1706/1.Data/RAW/occurrences/cleaned"



# occs1 <- fread(paste0(occs_dir,"/GBIF_joined_FINAL_20260317.csv"))
# occs_total <- fread(paste0(occs_dir,"/GBIF_joined_FINAL_20260317.csv"))
# occs_2 <- fread(paste0(occs_dir,"/GBIF_data_third_round_cleaned_FINAL_2.csv"))
# occs_3 <- fread(paste0(occs_dir,"/GBIF_joined_FINAL_3.csv"))
# occs_final <- fread(paste0(occs_dir,"/GBIF_joined_FINAL_20260317_spList_filtered.csv"))
#   
#   
result_conv_dir <- paste0(result_dir, "/concave_hull_rasters_ADM0")
occs_split_dir  <- paste0(result_dir, "/occs_by_species")
# 
# occs_i <- occs1[which(occs1$species_searched==sp),]
# occs_i_total <- occs_total[which(occs_total$species_searched==sp),]
# occs_i_final <- occs_final[which(occs_final$species_searched==sp),]
# occs_i2 <- occs_2[which(occs_2$species_searched==sp),]
# occs_i3 <- occs_3[which(occs_3$species_searched==sp),]

for (i in 1:length(spList)){
  print(i)
  # i <- 111
  sp_name <- spList[[i]]
  out_file <- file.path(result_conv_dir, paste0(sp_name, "_conc.tif"))
  if (file.exists(out_file)) {message(paste0("SKIP (exists): ", sp_name)) }
  
  sp_csv <- file.path(occs_split_dir, paste0(sp_name, ".csv"))
  if (!file.exists(sp_csv)) {message(paste0("SKIP (no occs file): ", sp_name)) }
  
  occs_i <- data.table::fread(sp_csv)
  if (nrow(occs_i) < 4) {message("NO ENOUGH RECORDS")} else {
    sp_csv <- paste0(occs_split_dir,"/",sp_name,".csv")
    occs_i <- data.table::fread(sp_csv)
    
    sf::sf_use_s2(FALSE)
    occs_sf <- sf::st_as_sf(occs_i, coords = c("lon", "lat"), crs = 4326)
    conv_i  <- concaveman::concaveman(occs_sf)
    sf::st_crs(conv_i) <- 4326
    conv_i <- sf::st_make_valid(conv_i)
    
    if (nrow(occs_i) < 4) { p(); return(paste0("SKIP (< 3 pts): ", sp_name)) }
    conv_clipped <- sf::st_intersection(conv_i, adm0_w)
    if (nrow(conv_clipped) == 0) {(paste0("SKIP (empty intersection): ", sp_name)) }
    conv_clean <- conv_clipped |>
      sf::st_collection_extract("POLYGON") |>
      sf::st_cast("MULTIPOLYGON")
    
    r <- terra::rasterize(terra::vect(conv_clean), tmpl, field = 1, background = NA)
    r <- terra::mask(r, tmpl)
    r[which(r[] != 0)] <- 1
    terra::writeRaster(r, out_file, overwrite = TRUE) 
  }
  
  
}

