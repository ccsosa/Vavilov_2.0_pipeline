# load packages
library(terra)

# set user of the script
user <- 'Chrystian'


if (user == "Chrystian") {
  basedir <- "//catalogue/MultifLandscapesA1706/1.Data/Results"
}


# load species set for which distributions models should be made
setwd(dir = paste0(basedir, "/SDM results"))
species_set <- read.csv("species_set_SDM_all.csv")
species_set <- species_set[, 1]
# j <- which(species_set$incl == "yes")
# species_set <- species_set$species[j]

# GCMs and SSPs
GCMs <- c("ACCESS-CM2",
          "GISS-E2-1-G",
          "INM-CM5-0",
          "MIROC6",
          "MPI-ESM1-2-HR")
SSPs <- c("ssp245", "ssp370")
year <- "2050"


output_dir <-
  paste0(basedir, "/SDM results/", "Distribution maps/Future/", year)
output_dir <-  paste0(output_dir, "/", "Consensus_maps_folder")
output_dir_fut <-  paste0(output_dir, "/", "Fut_consensus")

output_changes_dir <-  paste0(output_dir, "/", "changes_FC")
output_changes_csv_dir <-  paste0(output_dir, "/", "changes_CSV")

output_SUM_dir <-  paste0(output_dir, "/", "sums")





if (!dir.exists(output_dir)) {
  dir.create(output_dir)
}

if (!dir.exists(output_changes_dir)) {
  dir.create(output_changes_dir)
}

if (!dir.exists(output_SUM_dir)) {
  dir.create(output_SUM_dir)
}

if (!dir.exists(output_dir_fut)) {
  dir.create(output_dir_fut)
}

if (!dir.exists(output_changes_csv_dir)) {
  dir.create(output_changes_csv_dir)
}
current_dir <-
  paste0(basedir,
         "/SDM results/",
         "Distribution maps",
         "/",
         "Presence-absence")

# for-loop



#Alnus acuminata failing
for (i in 1:length(species_set)) {
  if (file.exists(paste0(current_dir, "/", species_set[[i]], ".tif"))) {
    # i <- 1
    print(i)
    print(species_set[i])
    current_sdm <-
      terra::rast(paste0(current_dir, "/", species_set[[i]], ".tif"))
    
    expanse_ssp <- list()
    for (s in 1:length(SSPs)) {
      # s <- 1
      print(SSPs[s])
      
      # make empty list to store rasters
      p_list <- list()
      
      for (g in 1:length(GCMs)) {
        GCM_dir <- paste0(
          basedir,
          "/SDM results/",
          "Distribution maps/Future/",
          year,
          "/",
          GCMs[g],
          "/",
          SSPs[s]
        )
        
        print(GCMs[g])
        
        if(file.exists(paste0(GCM_dir,"/",species_set[i], "_", year, ".tif"))){
          setwd(dir = GCM_dir)
          
          p_list[[g]] <-
            rast(paste0(species_set[i], "_", year, ".tif"))
        } else {
          p_list[[g]] <- NULL 
        }
        # g <- 1
      }
      
      # convert to rasterstack
      
      p_list <- p_list[!sapply(p_list, is.null)]
      
      if(length(p_list)>0){
        p <- terra::rast(p_list)
        message(paste0(
          "summarizing projections in one for: ",
          year,
          "/",
          GCMs[g],
          "/",
          SSPs[s]
        ))
        # presence if at least 3 models predict presence
        p_sum <- sum(p, na.rm = T)
        setwd(dir = output_SUM_dir)
        writeRaster(p_sum, paste0(species_set[i], ".tif"), overwrite = TRUE)
        
        p_sum[p_sum < 3] <- 0
        p_sum[p_sum > 0] <- 1
        
        p_sum2 <- p_sum
        p_sum2[p_sum2 == 1] <- 2
        # p_sum[p_sum ==0] <- NA
        # plot(p_sum, main = species_set[i])
        #
        # save
        setwd(dir = output_dir_fut)
        writeRaster(p_sum, paste0(species_set[i], ".tif"), overwrite = TRUE)
        
        message(
          paste0(
            "Calculating changes for: ",
            species_set[i],
            "/",
            year,
            "/",
            GCMs[g],
            "/",
            SSPs[s]
          )
        )
        current_sdm <- terra::resample(current_sdm,p_sum2,"near")
        #Creating raster with changes
        changes <- p_sum2 - current_sdm
        changes[changes == 0] <- NA
        x_expanse <- terra::expanse(changes,unit="km",byValue=T,wide=F)
        x_expanse$layer <- species_set[i]
        x_expanse$year <- year
        # x_expanse$GCM <- GCMs[g]
        x_expanse$SSP <- SSPs[s]
        expanse_ssp[[s]] <- x_expanse
        #saving impact
        setwd(dir = output_changes_dir)
        writeRaster(changes, paste0(species_set[i], ".tif"), overwrite = TRUE)
        
      } else {
        message("no files to do changes")
      }
      
      
     
    }
    
    expanse_ssp <- do.call(rbind,expanse_ssp)
     setwd(dir = output_changes_csv_dir)
    write.csv(expanse_ssp, paste0(species_set[i],"_areas", ".csv"),row.names = F)
  } else {
    message("skipping..")
  }
}
