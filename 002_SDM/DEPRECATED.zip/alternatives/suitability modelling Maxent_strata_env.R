## Distribution modelling script for D4R cacao

## summary SDM methodology:
# target-group background points
# spatial block cross-validation (blockCV package)
# environmental filtering
# tuning of Maxent parameter settings (ENMeval)

## content script
# part 0: Preparations
# part 1: Preparation of presence data and target group grid
# part 2: Distribution modelling

#### PART 0: Preparations ####
options(java.parameters = "-Xmx4g") 

# load packages
library(raster)
library(dismo)
library(rgeos)
library(rgdal)
library(blockCV)
library(rJava)
library(ENMeval)
library(ecospat)
library(data.table)
library(viridis)
library(sf)
library(terra)
library(usdm)
library(pROC)
library(parallel)
###
#to heat up parallel (Somehow Parallel bothers a lot. This is suppose to work to
#avoid the issue: Error en unserialize(node$con): error al leer desde conexión)
cl <- makeCluster(2)
stopCluster(cl)
gc()
#
# set user of the script
user <- "Chrystian"
#user <- "Tobias"

# set base directory
if(user == "Chrystian") {
  basedir <- "D:/PROGRAMAS/Dropbox/SDM D4R"
}
# if(user == "Tobias") {
#   basedir <- "C:/Users/tobia/Dropbox/SDM D4R"
# }

# set target region
region<- "SA coffee"

# set output directory
outputdir <- paste0(basedir, "/SDM results/", region, "/Maxent 3")

# create dirs structure
dirs_to <- c(
  "Convex hulls","Distribution maps","Maxent models","Model evaluation","Model thresholds",
  "Response curves","Shapefiles","Training point maps","Tuning results","Variable importance",
  "Distribution maps/Presence-absence","Distribution maps/Suitability","Distribution maps/Pdfs")
for(i in 1:length(dirs_to)){
  x <- paste0(outputdir,"/",dirs_to[[i]])
  if(!dir.exists(x)){
    dir.create(x)
  }
}

# fix set seed
set.seed(1000)

# load climate data
setwd(dir = paste0(basedir, "/Input data/Climate data/Present/S-America"))
clim <- stack(list.files(pattern = ".tif$"))

# get bio1 and bio12 (for outlier detection)
bio_1 <- clim[["bio_1"]]
bio_12 <- clim[["bio_12"]]

# load soil and topography data
setwd(dir = paste0(basedir, "/Input data/Soil and topography data/S-America"))
soil_top <- stack(list.files(pattern = ".tif$"))

# put together
envstack <- stack(clim, soil_top)
x_names <- names(envstack)
crs(envstack) <- "+proj=longlat +datum=WGS84 +no_defs"

# remove some climatic variables
i <- which(names(envstack) %in% c("bio_8",
                                  "bio_9", 
                                  "bio_10", 
                                  "bio_11", 
                                  "bio_13", 
                                  "bio_14", 
                                  "bio_18", 
                                  "bio_19"))
envstack <- envstack[[-i]]

# load potential natural vegetation (ecoregions) map
setwd(dir = paste0(basedir, "/Input data/Other spatial data/", region))
ecoregions <- raster("ecoregions_modelling_extent.tif")
ecoregions <- crop(ecoregions, envstack)

# load raster of target countries
setwd(dir = paste0(basedir, "/Input data/Raster target region/", region))
target_region <- raster("target_region.tif")

# load altitude raster and crop
setwd(dir = paste0(basedir, "/Input data/Other spatial data/", region))
alt <- raster("merit_DEM_1km_modelling_extent.tif")
alt <- crop(alt, envstack)
alt_alt <- alt

# set values above 
alt_alt[alt_alt >= 4000] <- NA 
alt_alt[alt_alt < 4000] <- 1

# load adm0 shapefile
setwd(dir = paste0(basedir, "/Input data/Adm0/", region))
adm0 <- vect(paste0("adm0_", region, ".shp"))
# plot(adm0)

# load species set 
setwd(dir = paste0(basedir, "/Input data/Species/Priority species/", region))
species_set <- read.csv("species_set.csv")

# prepare ref raster for 30 arcsec spatial filtering
ref_30arcsec <- envstack[[1]]

# prepare ref raster for 2.5 arcmin (ca. 5 km) spatial filtering
ref_2.5arcmin <- aggregate(ref_30arcsec, fact = 5)

# set which one of the two to use
ref <- ref_2.5arcmin

# prepare environmental data target countries
envstack_target <- crop(envstack, target_region)
envstack_target <- resample(envstack_target, target_region)
envstack_target <- mask(envstack_target, target_region)

# make raster of Sechura desert
# desert <- ecoregions
# desert[desert != 608] <- NA

#### PART 1: Preparation of presence data and sampling intensity grid ####

# load presence points
setwd(dir = paste0(basedir, "/Input data/Occurrence records/", region, "/Cleaned"))
#Reading main file
p1 <- read.csv("GBIF_data_SA coffee_cleaned.csv")
p1 <- p1[,c("species", "lon", "lat")]
#listing files and excluding the main file
files_to <- list.files(paste0(basedir, "/Input data/Occurrence records/", region, "/Cleaned"))
files_to <- files_to[files_to!="GBIF_data_SA coffee_cleaned.csv"]

input_data <- lapply(1:length(files_to),function(i){
  # print(i)
  #read using fread to avoid any missmatch in column names
  x <- data.table::fread(paste0(basedir,"/Input data/Occurrence records/",
                                region,"/","cleaned","/",files_to[[i]]))
  #Column names to use for approach
  colnames_lower <- colnames(x)
  #Dictionary of fields
  species_names <- c("species_cleaned", "species", "species_cleaned", "scientific_name", "Species", "especie", "nombre_cientifico")
  longitude_names <- c("longitude", "lon", "long", "x_longitud","Long")
  latitude_names <- c("latitude", "lat", "y_latitud","Lat")
  #Search for matches using the dictionary for species, long and lat
  get_column <- function(possible_names, colnames_all) {
    #match
    match <- which(colnames_all %in% possible_names)
    #ensuring match
    if (length(match) == 0) stop("No matching column found.")
    #getting the subset
    return(colnames(x)[match[1]])  # nombre original
  }
  #get the column names for species, long and lat
  species_col <- get_column(species_names, colnames_lower)
  lon_col     <- get_column(longitude_names, colnames_lower)
  lat_col     <- get_column(latitude_names, colnames_lower)
  #Standardize columns and subset
  x <- x[, .SD, .SDcols = c(species_col, lon_col, lat_col)]
  colnames(x) <- c("species", "lon", "lat")
  #Ensuring names in species_set
  x <- as.data.frame(x[x$species %in% species_set$species])
  unique(x)
  #excluding NAs values
  x <- x[complete.cases(x),]
  return(x)
})  

input_data <- do.call(rbind,input_data)
p1 <- rbind(p1,input_data)
presence <- p1

# make a copy of the presence data and convert to spatial dataframe
# TG_sp <- presence
# coordinates(TG_sp) <- cbind(TG_sp$lon, TG_sp$lat)
# 
# # rasterize the occurrence records
# l <- length(TG_sp)
# v <- rep(1, l)
# TG_raster <- rasterize(TG_sp, ecoregions, field = v, fun = 'count')
# TG_raster[TG_raster <= 0] <- NA
# rm(TG_sp)
TG_raster <- raster("D:/PROGRAMAS/Dropbox/SDM D4R/Input data/Occurrence records/TG_latam_BG/cleaned/target_group_grid.tif")

# how many grid cells with species observations do we have?
print(length(which(getValues(TG_raster) > 0)))

# save the TG group raster
# setwd(dir = outputdir)
# writeRaster(TG_raster, "target_group_grid", format = "GTiff", overwrite = TRUE)

# check number of records per species after 5 km spatial filtering
results <- data.frame(
  species = species_set$species,
  n = NA
)
for (i in 1:length(species_set$species)) {
  print(i)
  j <- which(presence$species == species_set$species[i])
  presence_subset <- presence[j,]
  presence_filtered <- data.frame(gridSample(presence_subset[,c("lon", "lat")], r = ref))
  results$n[i] <- nrow(presence_filtered)
}
i <- which(results$n > 29)
species_set <- results$species[i]
species_set <- sort(species_set)

# save
setwd(dir = outputdir)
write.csv(species_set, "species_set_SDM.csv")

################################################################################
################################################################################
################################################################################
################################################################################
#### PART 2: Suitability modelling ####

# set size of blocks
range <- 200000 
species_set<- species_set[c(21,31,74,91,93)]

# species_set <- species_set[c(6,26,27,28,30,33,93,106)]
for (i in 1:length(species_set)) {
  message(region,"\n")
  # i <- 1  
  # set species name and select only the occurrence records of this species
  species_name <- species_set[i]
  message(species_name)
  message(i)
  
  j <- which(presence$species == as.character(species_name)) 
  presence_species <- presence[j,]
  presence_species <- data.frame(lon = presence_species$lon,lat = presence_species$lat)
  
  # 5 km gridsample
  presence_species <- data.frame(gridSample(presence_species[,c("lon", "lat")], r = ref))
  names(presence_species) <- c("lon", "lat")
  
  # for Citrus species use presence points of other species too
  if(grepl("Citrus", species_name)) {
    j <- grep("Citrus", presence$species)
    presence_species <- presence[j,]
    presence_species <- data.frame(lon = presence_species$lon,lat = presence_species$lat)
  }
  
  # delete environmental outliers
  # based on bio_1
  e <- raster::extract(bio_1, cbind(presence_species$lon, presence_species$lat))
  q1 <- quantile(e, 0.25, na.rm = TRUE)
  q3 <- quantile(e, 0.75, na.rm = TRUE)
  IQR <- IQR(e, na.rm = TRUE)
  lower_lim <- q1 - 3*IQR
  higher_lim <- q3 + 3*IQR
  l <- which(e < lower_lim)
  h <- which(e > higher_lim)
  if(length(l) > 1 | length(h) > 1) {
    presence_species <- presence_species[-c(l,h),]
  }
  # based on bio_12
  e <- raster::extract(bio_12, cbind(presence_species$lon, presence_species$lat))
  q1 <- quantile(e, 0.25, na.rm = TRUE)
  q3 <- quantile(e, 0.75, na.rm = TRUE)
  IQR <- IQR(e, na.rm = TRUE)
  lower_lim <- q1 - 3*IQR
  higher_lim <- q3 + 3*IQR
  l <- which(e < lower_lim)
  h <- which(e > higher_lim)
  if(length(l) > 1 | length(h) > 1) {
    presence_species <- presence_species[-c(l,h),]
  }
  
  
  # removing presences above 4000 masl
  occ4000_i <- extract(alt_alt, presence_species)
  presence_species <- presence_species[which(occ4000_i == 1), ]
  
  
  message("fitting pseudoabsences to convex hull...")
  # define a convex hull around the presence points with a buffer corresponding to 10% of the longest axis
  # first convert to SpatialPointsDataFrame
  occ_sp <- presence_species
  coordinates(occ_sp) <- cbind(occ_sp$lon, occ_sp$lat)
  crs.geo <- CRS("+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0")
  proj4string(occ_sp) <- crs.geo
  # calculate distance of longest axis of presence points
  largedist <- max(pointDistance(occ_sp, longlat = TRUE), na.rm = T)
  # define hull around presence points
  occ_coords <- as.matrix(data.frame(occ_sp$lon, occ_sp$lat))
  ch <- chull(occ_coords)
  hull_coords <- occ_coords[c(ch, ch[1]), ]
  hull <- SpatialPolygons(list(Polygons(list(Polygon(hull_coords)), ID = 1)))
  proj4string(hull) <- crs.geo
  # 20% longest axis distance buffer # TF: changed to 20%
  hull_ext <- raster::buffer(hull, width = 0.20 * largedist)
  # plot to check if everything OK
  # plot(ecoregions)
  # plot(occ_sp, pch = 19, cex = 0.4, add = TRUE)
  # plot(hull, add = TRUE)
  # plot(hull_ext,border="red", add = TRUE)
  # rasterize the convex hull
  hullRaster <- rasterize(hull_ext, ecoregions, field = 1)
  hullRaster <- alt_alt*hullRaster
  
  # save convex hull as raster
  setwd(paste0(outputdir, "/convex hulls", sep = ""))
  writeRaster(hullRaster, filename = paste0("convex hull ", species_name, sep = ""),
              format = "GTiff", overwrite = TRUE)
  
  # save convex hull as shapefile
  dsn <- paste0(outputdir, "/shapefiles/", sep = "")
  shapefile(x = hull_ext, 
            file = paste0(dsn, "/convex hull 1", species_name, ".shp", sep = ""),
            overwrite = TRUE)
  
  # # use the convex hull as a mask for the target group grid
  # TG_masked <- resample(x = TG_raster,y = hullRaster)
  # TG_masked <- mask(x = TG_masked, mask = hullRaster)
  # 
  # ## selection of background/absence points with the target group approach
  # # how much non-empty grid cells in the masked target group grid?
  # n_TG_masked <- length(which(values(TG_masked) > 0))
  # message(n_TG_masked)
  
  # aim for 20,000 background points, otherwise take the number of 
  # non-empty grid cells
  # if(n_TG_masked > 20000) {
  #   n_maxent <- 20000
  # } else {
  #   n_maxent <- n_TG_masked
  # }
  
  message("Using strataenv with ecoregions...trying reach 20000 PA")
  n_maxent <- 20000
  # envstack_target_hull <- crop(envstack_target,hullRaster)
  # envstack_target_hull <- resample(envstack_target_hull,hullRaster)
  # envstack_target_hull <-  mask(envstack_target_hull,hullRaster)
  # 
  # dif
  eco_hull <- hullRaster
  eco_hull <- eco_hull* ecoregions
  # plot(eco_hull)
  
  n_strata <- length(na.omit(unique(eco_hull[])))
  background <- sampleStratified(eco_hull,
                                 size = floor(n_maxent/n_strata),
                                 na.rm=T,
                                 xy=T,
                                 exp=10)
  background<- as.data.frame(background[,c(2,3)])
  names(background) <- c("lon", "lat")
  
  
  message(paste0("bg size: ",nrow(background)))
  # # sample the desired number of background points
  # option2 <- T
  # if(option2 == T) {
  #   message("using target group and random background")
  #   # target group background records
  #   background_TG <- data.frame(crds(rast(TG_masked))) # TF: converting to terra format
  #   s <- sample(x = nrow(background_TG), size = n_maxent/2)
  #   background_TG <- background_TG[s,c("x", "y")]
  #   names(background_TG) <- c("lon", "lat")
  #   # 5 km filtering (2.5 arcmin) of background points
  #   background_TG <- data.frame(gridSample(background_TG[,c("lon", "lat")], r = ref))
  #   names(background_TG) <- c("lon", "lat")
  #   # random background records
  #   background_random <- data.frame(randomPoints(hullRaster, n = nrow(background_TG), tryf = 3))
  #   names(background_random) <- c("lon", "lat")
  #   # put together
  #   background <- rbind(background_TG, background_random)
  # } else {
  #   message("using target group background")
  #   background_TG <- data.frame(crds(rast(TG_masked))) # TF: converting to terra format
  #   s <- sample(x = nrow(background), size = n_maxent)
  #   background <- background[s,c("x", "y")]
  #   names(background) <- c("lon", "lat")
  #   background <- data.frame(gridSample(background[,c("lon", "lat")], r = ref))
  #   names(background) <- c("lon", "lat")
  # }
  # 
  # # 5 km filtering (2.5 arcmin) of background points
  # background <- data.frame(gridSample(background[,c("lon", "lat")], r = ref))
  # names(background) <- c("lon", "lat")
  
  # plot the presence and background points
  bg <- background
  p <- presence_species
  coordinates(bg) <- cbind(bg$lon, bg$lat)
  coordinates(p) <- cbind(p$lon, p$lat)
  
  # save this map
  message("saving training points as PDF map...")
  
  setwd(dir = paste0(outputdir, "/Training point maps"))
  pdf(paste0(species_set[i],".pdf"), height = 8, width = 8)
  plot(ecoregions)
  plot(hull,border="black",add = TRUE)
  plot(hull_ext,border="red", add = TRUE)
  points(bg[,c(1,2)], pch=20, cex=0.2, col="gray30")
  points(p[,c(1,2)], pch=20, cex=0.4, col = "red")
  dev.off()
  
  # extract environmental data at presence and background locations
  e_p <- raster::extract(envstack, cbind(presence_species$lon, presence_species$lat))
  presence_species <- cbind(presence_species, e_p)
  e_bg <- raster::extract(envstack, cbind(background$lon, background$lat))
  background <- cbind(background[,1:2], e_bg)
  
  # prepare presence and background data for the spatial block cross-validation
  p <- presence_species
  p$type = 1
  a <- background
  a$type = 0
  dat <- rbind(p,a)
  coordinates(dat)<- cbind(dat$lon, dat$lat)
  crs(dat) <- crs(ref)
  
  
  message("Spatial blocks...")
  # get spatially independent blocks to check how many folds can be used (aim for 8 but use less
  # if necessary: each fold has to have testing presence and absence data)
  # first prepare presence-absence data
  # set the number of folds
  k <- 8
  # set the min. number of testing points minus 1
  min_n <- 3

  # try if 8 folds works
  k <- 8
  t <- try(
    sb <- spatialBlock(speciesData = dat,
                       species = "type",
                       rasterLayer = bio_1,
                       theRange = range,
                       k = k,
                       progress = F,
                       verbose=F,
                       showBlocks=F)
  )
  testpoints <- append(sb$records$test_0, sb$records$test_1)
  if (!all(testpoints > min_n)) {
    class(t) <- "try-error"
  }

  # try with 7 folds
  if (class(t) == "try-error") {
    k <- 7
    t <- try(
      sb <- spatialBlock(speciesData = dat,
                         species = "type",
                         rasterLayer = bio_1,
                         theRange = range,
                         k = k,
                         progress = F,
                         verbose=F,
                         showBlocks=F)
    )
  }
  testpoints <- append(sb$records$test_0, sb$records$test_1)
  if (!all(testpoints > min_n)) {
    class(t) <- "try-error"
  }

  # try with 6 folds
  if (class(t) == "try-error") {
    k <- 6
    t <- try(
      sb <- spatialBlock(speciesData = dat,
                         species = "type",
                         rasterLayer = bio_1,
                         theRange = range,
                         k = k,
                         progress = F,
                         verbose=F,
                         showBlocks=F)
    )
  }
  testpoints <- append(sb$records$test_0, sb$records$test_1)
  if (!all(testpoints > min_n)) {
    class(t) <- "try-error"
  }

  # try with 5 folds
  if (class(t) == "try-error") {
    k <- 5
    t <- try(
      sb <- spatialBlock(speciesData = dat,
                         species = "type",
                         rasterLayer = bio_1,
                         theRange = range,
                         progress = F,
                         k = k,
                         verbose=F,
                         showBlocks=F)
    )
  }
  testpoints <- append(sb$records$test_0, sb$records$test_1)
  if (!all(testpoints > min_n)) {
    class(t) <- "try-error"
  }

  # try with 4 folds
  if (class(t) == "try-error") {
    k <- 4
    t <- try(
      sb <- spatialBlock(speciesData = dat,
                         species = "type",
                         rasterLayer = bio_1,
                         theRange = range,
                         k = k,
                         progress = F,
                         verbose=F,
                         showBlocks=F)
    )
  }
  testpoints <- append(sb$records$test_0, sb$records$test_1)
  if (!all(testpoints > min_n)) {
    class(t) <- "try-error"
  }

  # prepare spatial block partition groups for use in ENMevaluate
  j <- which(dat$type == 1)
  occs.grp <- sb$foldID[j]
  bg.grp <- sb$foldID[-j]
  user_grp <- list(occs.grp, bg.grp)
  names(user_grp) <- c("occs.grp", "bg.grp")
  
  
  
  message("ENMEvaluate...")
  
  # tuning arguments
  tune.args <- list(fc = c("LQ","LQH","H","LQHP"), rm = c(1,3,5))
  
  # to ensure parallel works
  # library(parallel)
  rscript_args = c("-e", shQuote("getRversion()"))
  
  
  # rand <- get.randomkfold(presence_species, background, k = 5)
  
  maxent_tuning <- ENMeval::ENMevaluate(
    occ = presence_species,
    bg = background,
    algorithm = "maxent.jar",
    tune.args = tune.args,
    user.grp = user_grp,
    partitions = "user",
    quiet=TRUE,
    parallel =  T,
    numCores = 4
  )
  
  # save the tuning results
  setwd(dir = paste0(outputdir, "/Tuning results"))
  write.csv(maxent_tuning@results, paste0(species_name, ".csv"))
  
  
  message("Best model using CBI...")
  
  # select model with the highest CBI
  bestmod <- which.max(maxent_tuning@results$cbi.val.avg)
  
  # get model evaluation metrics of this model
  bestmod_eval <- maxent_tuning@results[bestmod,]
  # bestmod_eval
  
  # save model evaluation metrics
  setwd(dir = paste0(outputdir, "/Model evaluation"))
  write.csv(bestmod_eval, paste0("model_evaluation_", species_name, ".csv"))
  
  # make predictions of the best model, only for the target region
  pr <- predict(stack(envstack_target), maxent_tuning@models[[bestmod]], type = 'cloglog')
  # plot
  # plot(pr)
  
  message("Evaluating model...")
  
  # make predictions for the presence and background points
  suit_pres <- predict(maxent_tuning@models[[bestmod]], presence_species)
  suit_bg <- predict(maxent_tuning@models[[bestmod]], background)
  
  # evaluate predictive ability of model
  suit_pres <- c(suit_pres)
  suit_bg <- c(suit_bg)
  ev <- dismo::evaluate(p = suit_pres, a = suit_bg)
  
  # get possible thresholds to convert suitability to presence/absence
  thr <- threshold(ev)
  
  # add "10% omission" threshold
  thr$thr_om <- quantile(suit_pres, 0.1, na.rm = TRUE)
  #thr
  
  # apply 10% omission threshold
  pr_thr <- pr > thr$thr_om
  
  # extra evaluation
  if(user == "Chrystian") {
    pred_pres_bin <- as.numeric(suit_pres >= thr$thr_om)
    pred_bg_bin   <- as.numeric(suit_bg >= thr$thr_om)
    
    # observed values (1 for presence, 0 for background)
    observed <- c(rep(1, length(suit_pres)), rep(0, length(suit_bg)))
    predicted <- c(pred_pres_bin, pred_bg_bin)
    
    # confusion matrix
    conf_mat <- table(Predicted = predicted, Observed = observed)
    TP <- conf_mat["1", "1"]
    FN <- conf_mat["0", "1"]
    sensitivity <- TP / (TP + FN)
    TN <- conf_mat["0", "0"]
    FP <- conf_mat["1", "0"]
    specificity <- TN / (TN + FP)
    
    bestmod_eval$sensitivity <- sensitivity
    bestmod_eval$specificity <- specificity
    bestmod_eval$TSS <- (sensitivity + specificity)-1
    bestmod_eval$OPR <- FP/(TP+FP)
    bestmod_eval$UPR <- FN/(TP+FN)
    # bestmod_eval$F1 <- (2*TP)/(FN+(2*TP)+FP)
  }
  
  # save model evaluation metrics
  setwd(dir = paste0(outputdir, "/Model evaluation"))
  write.csv(bestmod_eval, paste0("model_evaluation_", species_name, ".csv"))
  
  # save model threshold
  setwd(dir = paste0(outputdir, "/Model thresholds"))
  write.csv(data.frame(thr), paste0(species_name, ".csv"))
  
  # apply "equal sensitivity and specificity" threshold
  pr_thr <- pr > thr$equal_sens_spec
  pr_thr <- pr > thr$spec_sens
  
  # save the maps
  setwd(dir = paste0(outputdir, "/Distribution maps/Presence-absence")) 
  writeRaster(pr_thr, species_name, format = "GTiff", overwrite = TRUE)
  setwd(dir = paste0(outputdir, "/Distribution maps/Suitability"))
  writeRaster(pr, species_name, format = "GTiff", overwrite = TRUE)
  
  # only select the points inside the target region for plotting
  e <- raster::extract(pr_thr, cbind(presence_species$lon, presence_species$lat))
  j <- which(is.na(e))
  if(length(j)>0) {
    presence_species <- presence_species[-j,]
  }
  
  message("Saving model, response curves and variable importance...")
  
  # save the maps as pdfs
  setwd(dir = paste0(outputdir, "/Distribution maps/Pdfs"))
  pdf(paste0(species_name, ".pdf"), width = 10, height = 5)
  par(mfrow = c(1,2))
  par(mai = c(0.5, 0.5, 0.5, 0.5))
  plot(pr, main = paste0("Suitability ", species_name), 
       legend = FALSE,
       col = viridis(100))
  plot(st_geometry(st_as_sf(adm0)), add = TRUE, border = "grey20", lwd = 1.25)   # need st_as_sf, st_geometry not working on a SpatVector object
  points(presence_species, pch = 19, cex = 0.3, col = "red")
  pr_thr[pr_thr==0] <- NA
  plot(pr_thr, main = paste0("Presence-absence ", species_name), 
       legend = FALSE, col = "grey50")
  plot(st_geometry(st_as_sf(adm0)), add = TRUE, border = "grey20", lwd = 1.25)
  points(presence_species, pch = 19, cex = 0.3, col = "red")
  dev.off()
  par(mfrow = c(1,1))
  
  # save the model
  setwd(dir = paste0(outputdir, "/Maxent models"))
  maxent_mod <- maxent_tuning@models[[bestmod]]
  save(maxent_mod, file = paste0("maxent_model_", species_name, ".RData"))
  
  # variable importance
  varimport <- maxent_tuning@variable.importance[[bestmod]]
  setwd(dir = paste0(outputdir, "/Variable importance"))
  write.csv(varimport, paste0(species_name, ".csv"))
  
  # response curves
  setwd(dir = paste0(outputdir, "/Response curves"))
  pdf(paste0("response curves ", species_name,".pdf"),
      width = 12, height = 10)
  par(mai = c(0.6,0.6,0.3,0.3))
  response(maxent_mod)
  # plot(pr, type = "l", las = 1)
  dev.off()
  
  message("Saving occurences, final step...")
  # save shapefile
  dsn <- paste0(outputdir, "/Shapefiles")
  writeOGR(occ_sp, species_name, driver = "ESRI Shapefile", dsn = dsn, overwrite = TRUE)
  message("DONE!")
}
