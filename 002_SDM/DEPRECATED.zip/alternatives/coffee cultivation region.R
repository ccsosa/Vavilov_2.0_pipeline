# load packages
library(terra)

# load coffee distribution map
setwd(dir = "C:/Users/tobia/Dropbox/SDM D4R/SDM results/SA coffee/Maxent coffee/Distribution maps/Presence-absence")
coffee <- rast("Coffea arabica.tif")
coffee[coffee == 0] <- NA
plot(coffee)

# load altitude raster and combine with coffee distribution map
setwd(dir = "C:/Users/tobia/Dropbox/SDM D4R/Input data/Other spatial data/SA coffee")
alt <- rast("merit_DEM_1km_modelling_extent.tif")
alt <- crop(alt, coffee)
alt <- resample(alt, coffee) 
alt <- mask(alt, coffee)
alt[alt < 700] <- NA
alt[alt > 2500] <- NA
alt[alt > 0] <- 1
plot(alt)

# save
setwd(dir = "C:/Users/tobia/Dropbox/SDM D4R/SDM results/SA coffee/Maxent coffee")
writeRaster(alt, "coffee_cult_region.tif", overwrite = TRUE)


