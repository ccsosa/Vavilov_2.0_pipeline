### this script cleans occurrence data (GBIF and BIEN data typically) using the following steps:
# remove data in urban areas
# remove records with imprecise coordinates
# remove data older than 1950
# remove data with region mismatch

# author: Tobias Fremout (tobias.fremout@gmail.com)

# load packages
library(terra)
library(sf)

# set base directory
basedir <- "C:/Users/tobia/Dropbox/SDM D4R"
  
# set target region
region<- "SA coffee"

# load shapefile with country borders of modelling region
setwd(dir = paste0(basedir, "/Input data/adm0/", region))
adm0 <- st_read(paste0("adm0_", region, ".shp"))

# load raster of modelling region
setwd(dir = paste0(basedir, "/Input data/Climate data/Present/S-America"))
t <- rast("bio_1.tif")
#plot(t)

# load urban areas raster
setwd(dir = paste0(basedir, "/Input data/Other spatial data/GHSL urban areas"))
urban <- rast("ghsl-population-built-up-estimates-degree-urban-smod_built-30ss-2014.tif")

# crop
urban <- crop(urban, t)
#plot(urban)
#plot(st_geometry(adm0), add=TRUE)

# load occurrence data to be cleaned
setwd(dir = paste0(basedir, "/Input data/Occurrence records/", region, "/Original"))
occ <- read.csv(paste0("GBIF_data_download_coffee.csv"))

# check everything OK
names(occ)
dim(occ)

# delete data in urban areas
extr <- terra::extract(urban, cbind(occ$lon, occ$lat))
i <- which(extr > 25)
if(length(i)>0) {
  occ <- occ[-i,]
}
print(paste0(length(i), " points deleted because located in urban areas"))

# change classes of columns if necessary
occ$lat <- as.numeric(occ$lat)
occ$lon <- as.numeric(occ$lon)
occ$year <- as.numeric(occ$year)
occ$region <- region
occ$region <- as.character(occ$region) 

# define a function to count the number of decimal places
decimalplaces <- function(x) {
  if ((x %% 1) != 0) {
    strs <- strsplit(as.character(format(x, scientific = F)), "\\.")
    n <- nchar(strs[[1]][2])
  } else {
    n <- 0
  }
  return(n) 
}

# remove records with imprecise coordinates (2 decimal places needed for a precision of 1.1 km)

# count decimal places of lon and lat coordinates
dec_lon <- sapply(occ$lon, FUN = decimalplaces)
dec_lat <- sapply(occ$lat, FUN = decimalplaces)

# identify records with zero decimal places for lon OR lat
# the probability of these records to be precise enough (actually having .00 as decimal places) is 1/100
i <- which(dec_lon == 0 | dec_lat == 0)
if(length(i)>0) {
  occ <- occ[-i,]
}
print(paste0(length(i), " points deleted because of imprecise coordinates"))

# delete records with only 1 decimal place in lon AND lat
# the probability of these records to be precise enough is (1/10)^2 = 1/100
i <- which(dec_lon == 1 & dec_lat == 1)
if(length(i)>0) {
  occ <- occ[-i,]
}
print(paste0(length(i), " points deleted because of imprecise coordinates"))

# delete data older than 1950 (high probability of not being precise enough)
i <- which(occ$year < 1950)
if(length(i)>0) {
  occ <- occ[-i,]
}
print(paste0(length(i), " points deleted because older than 1950"))

# make spatial dataframe
crs.geo <- "+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"
occSp <- sf::st_as_sf(x = occ, coords = c("lon", "lat"), crs = crs.geo)

# identify records with region mismatch
st_crs(adm0) <- crs.geo
overlay <- sf::st_intersection(occSp, adm0)
occ <- overlay
j <- which(occ$country != occ$NAME_0)
if(length(j)>0) {
  occ <- occ[-j,]
}
print(paste0(length(j), " points deleted because of region mismatch"))

# get coordinates
coords <- sf::st_coordinates(occ)

# convert to dataframe and add coordinates
occ_df <- as.data.frame(occ)
occ_df$lon <- coords[,1]
occ_df$lat <- coords[,2]
dim(occ_df)

#to check points
points(st_geometry(occ)) 
# write data to .csv file, manually check the adm0 (region) mismatches
setwd(dir = paste0(basedir, "/Input data/Occurrence records/", region, "/Cleaned"))
write.csv(occ_df, paste0("GBIF_data_coffee_cleaned.csv"))



