### this script can be used to put the AUC values and thresholds of the
# calibrated models in a single table

# author: Chrystian Sosa

library(terra)
library(viridis)
library(sf)
library(foreach)
library(bit)
# library(ggplot2)
library(bit)
require(leaflet)
library(htmlwidgets)
library(viridisLite)


changing_maps <- function(basedir,output_dir,species_selected,template){
#creating maps directory
output_dir_maps  <-
  paste0(output_dir, "/SDM_buffer_results_all")
if (!dir.exists(output_dir_maps)) {
  dir.create(output_dir_maps)
}
#creating outcomes folder (PNG)
output_dir_maps_PNG  <-
  paste0(output_dir_maps, "/PNG")
if (!dir.exists(output_dir_maps_PNG)) {
  dir.create(output_dir_maps_PNG)
}
#creating outcomes folder (GeoTIFF)
output_dir_maps_TIF  <-
  paste0(output_dir_maps, "/TIF")
if (!dir.exists(output_dir_maps_TIF)) {
  dir.create(output_dir_maps_TIF)
}
#creating outcomes folder (HTML files)
output_dir_maps_HTML  <-
  paste0(output_dir_maps, "/HTML")
if (!dir.exists(output_dir_maps_HTML)) {
  dir.create(output_dir_maps_HTML)
}  
#creating transitory outcomes folder
output_dir_chunks  <-
  paste0(output_dir_maps, "/chunks")
if (!dir.exists(output_dir_chunks)) {
  dir.create(output_dir_chunks)
}  
#creating outcomes folder (GeoTIFF) for future
output_dir_TIF_CH  <-
  paste0(output_dir_maps, "/TIF_CH")
if (!dir.exists(output_dir_TIF_CH)) {
  dir.create(output_dir_TIF_CH)
}  
#########################################################################################
#loading adm0
message("loading shapefile and metrics")
adm0 <- vect(paste0(basedir, "/1.Data/RAW/input_data/adm0/adm0_Latam", ".shp"))
#########################################################################################
#getting all species
species_total <- unique(species_selected$species)
#########################################################################################
#loading buffer species
InDir_buffer <- "//catalogue/MultifLandscapesA1706/1.Data/Results/buffer_richness/raster"
#species with buffer
sp_buffer_list <- list.files(InDir_buffer,pattern = ".tif")
sp_buffer_list_name <- sub(pattern = ".tif",replacement = "",sp_buffer_list)
#################################################################################################################################################

#############################################################################
#load metrics to get modeled species
metrics <- read.csv(paste0(resultdir,"/","AUC_Maxent_valid_all.csv"))
#gettting species lists to get results (modeled species with MaxEnt)
species_list <- metrics$species
species_list <- sub(pattern = "model_evaluation_",replacement = "",species_list)
species_list <- sub(pattern = ".csv",replacement = "",species_list)
#adding presence absence results folder
InDir <-
  paste0(resultdir, "/Distribution maps/Presence-absence")

#getting all possible species with results
sp_modeled_availa <- list.files(InDir, pattern = ".tif")
sp_modeled_availa <- sub(".tif", "", sp_modeled_availa)
##############################################################################
#load metrics to get modeled species
metrics <-
  read.csv(paste0(resultdir, "/", "AUC_Maxent_valid_all.csv"))
#gettting species lists to get results (modeled species with MaxEnt)
species_list <- metrics$species
species_list <-
  sub(pattern = "model_evaluation_", replacement = "", species_list)
species_list <-
  sub(pattern = ".csv", replacement = "", species_list)
# # print(length(species_list))
# # species_list <- species_list[which(species_list!="Cabralea canjerana")]
# # print(length(species_list))
# ################################################################################
# #species with valid model in the folder
# avail_sp_modeled <-
#   species_list[species_list %in% sp_modeled_availa]
# ################################################################################
# #fixing names
# #geting species names accepted
# accp_sp <-
#   conversion_table[conversion_table$species %in% avail_sp_modeled,]
# #getting synonym!
# syn_sp <-
#   conversion_table[conversion_table$species_from_source %in% avail_sp_modeled,]
# #only removing accepting to get the synonyms and accepted names
# syn_sp <- syn_sp[which(syn_sp$taxonomic_status != "Accepted"),]
# #getting available
# avail_sp_modeled <- c(accp_sp$species, syn_sp$species)
# #only getting unique species
# avail_sp_modeled <- unique(avail_sp_modeled)
# ##############################################################################
# #species with buffer
# # buffer_sps <- species_total[sp_buffer_list_name %in% species_total]
# buffer_sps <-
#   species_total[!species_total %in% avail_sp_modeled]
# #if buffer_sps + avail_sp_modeled =8221 is well done!
# buffer_sps <-
#   buffer_sps[buffer_sps %in% sp_buffer_list_name] #available to use buffer
# 
# buffer_sps <- unique(buffer_sps)
# ################################################################################
# 



print(length(species_list))
# species_list <- species_list[which(species_list!="Cabralea canjerana")]
# print(length(species_list))
#species with valid model
avail_sp_modeled <- species_list[species_list %in% species_total]
##############################################################################
#species with buffer
# buffer_sps <- species_total[sp_buffer_list_name %in% species_total]
buffer_sps <- species_total[!species_total %in% avail_sp_modeled] 
#if buffer_sps + avail_sp_modeled =8221 is well done!
buffer_sps <- buffer_sps[buffer_sps %in% sp_buffer_list_name] #available to use buffer
##############################################################################
#adding presence absence results folder
InDir <- paste0(resultdir,"/Distribution maps/Future/2050/Consensus_maps_folder/changes_FC")
##############################################################################
files <- list.files(InDir,".tif")
#load metrics to get modeled species
metrics <- read.csv(paste0(resultdir,"/","AUC_Maxent_valid_all.csv"))
#gettting species lists to get results (modeled species with MaxEnt)
species_list <- metrics$species
species_list <- sub(pattern = "model_evaluation_",replacement = "",species_list)
species_list <- sub(pattern = ".csv",replacement = "",species_list)
# print(length(species_list))
# species_list <- species_list[which(species_list!="Cabralea canjerana")]
# print(length(species_list))
#species with valid model
avail_sp_modeled <- species_list[species_list %in% species_total]
out_paths  <- paste0(InDir, "/", avail_sp_modeled, ".tif")

chunk_size <- 100                           # tune: lower = less RAM, more I/O passes

chunks <- split(out_paths, ceiling(seq_along(out_paths) / chunk_size))

chunk_stack_lis_neg <- list()
chunk_stack_lis_keep <- list()
chunk_stack_lis_new <- list()

for(k in seq_along(chunks)){
  # k <- 1

  message("Chunk ", k, " / ", length(chunks))
  chunk_stack <- rast(chunks[[k]])
  
  # load chunk_size layers
  # chunk_neg1  <- app(chunk_stack, fun = function(x) ifelse(x==-1,1,0))
  chunk_neg1<- app(chunk_stack==-1,fun="sum",na.rm=T)  
  chunk_keep<- app(chunk_stack==1,fun="sum",na.rm=T)
  chunk_new<- app(chunk_stack==2,fun="sum",na.rm=T)
  
  chunk_stack_lis_neg[[k]] <-chunk_neg1
    chunk_stack_lis_keep[[k]] <-chunk_keep
  chunk_stack_lis_new[[k]] <-chunk_new
  # sum_raster  <- sum_raster + chunk_sum
  # rm(chunk_stack, chunk_sum); gc()
}
chunk_stack_lis_neg <- do.call(c,chunk_stack_lis_neg)
chunk_stack_lis_keep <- do.call(c,chunk_stack_lis_keep)
chunk_stack_lis_new <- do.call(c,chunk_stack_lis_new)

chunk_stack_lis_neg   <- app(chunk_stack_lis_neg, fun = "sum", na.rm = TRUE)
chunk_stack_lis_keep   <- app(chunk_stack_lis_keep, fun = "sum", na.rm = TRUE)
chunk_stack_lis_new   <- app(chunk_stack_lis_new, fun = "sum", na.rm = TRUE)
gc()
# --- Step 3: write final richness raster for SDM * CH---
terra::writeRaster(
  chunk_stack_lis_neg,
  filename  = paste0(output_dir_maps_TIF, "/species_richness_LOSS_AREAS.tif"),
  overwrite = TRUE
)

terra::writeRaster(
  chunk_stack_lis_keep,
  filename  = paste0(output_dir_maps_TIF, "/species_richness_KEPT_AREAS.tif"),
  overwrite = TRUE
)
terra::writeRaster(
  chunk_stack_lis_new,
  filename  = paste0(output_dir_maps_TIF, "/species_richness_NEW_AREAS.tif"),
  overwrite = TRUE
)


#plotting lost areas

message("Making a plot")

#Plotting
par(mar = c(1, 1, 1, 1))

setwd(dir = paste0(output_dir_maps_PNG))
png(paste0("LATAM_Edible_food_","lost_areas_sp_richness", ".png"), width = 10, height = 10,
    units = "in",   # interpret as inches
    res = 1000)      # 300 dpi = print quality
par(mfrow = c(1,1))
par(mai = c(0.5, 0.5, 0.5, 0.5))
plot(chunk_stack_lis_neg,
     main="",
     #main = paste0("Species richness"),
     legend = T,
     col = viridis(length(species_list)))
plot(sf::st_geometry(sf::st_as_sf(adm0)), add = TRUE, border = "grey17", lwd = 1.25)
dev.off()


#plotting kept areas

message("Making a plot")

#Plotting
par(mar = c(1, 1, 1, 1))

setwd(dir = paste0(output_dir_maps_PNG))
png(paste0("LATAM_Edible_food_","kept_areas_sp_richness", ".png"), width = 10, height = 10,
    units = "in",   # interpret as inches
    res = 1000)      # 300 dpi = print quality
par(mfrow = c(1,1))
par(mai = c(0.5, 0.5, 0.5, 0.5))
plot(chunk_stack_lis_keep,
     main="",
     #main = paste0("Species richness"),
     legend = T,
     col = viridis(length(species_list)))
plot(sf::st_geometry(sf::st_as_sf(adm0)), add = TRUE, border = "grey17", lwd = 1.25)
dev.off()


#plotting new areas

message("Making a plot")

#Plotting
par(mar = c(1, 1, 1, 1))

setwd(dir = paste0(output_dir_maps_PNG))
png(paste0("LATAM_Edible_food_","new_areas_sp_richness", ".png"), width = 10, height = 10,
    units = "in",   # interpret as inches
    res = 1000)      # 300 dpi = print quality
par(mfrow = c(1,1))
par(mai = c(0.5, 0.5, 0.5, 0.5))
plot(chunk_stack_lis_new,
     main="",
     #main = paste0("Species richness"),
     legend = T,
     col = viridis(length(species_list)))
plot(sf::st_geometry(sf::st_as_sf(adm0)), add = TRUE, border = "grey17", lwd = 1.25)
dev.off()

}
user <- "Chrystian"
if(user == "Chrystian") {
  basedir <-  "//catalogue/MultifLandscapesA1706"
}

#config adding a results_dir
output_dir <- "//catalogue/MultifLandscapesA1706/1.Data/Results"


species_selected <- as.data.frame(
  readxl::read_xlsx(
    "//catalogue/MultifLandscapesA1706/1.Data/Results/species_lists/Species_20250304_edible_part_curated.xlsx",
    col_names = T
  )
)
resultdir <- "//catalogue/MultifLandscapesA1706/1.Data/Results/SDM results"

#template
#load template for rasterize
template <-
  rast(paste0(
    "//catalogue/MultifLandscapesA1706/1.Data/RAW/Input_data/climate_data/2_5min/present/",
    "wc2.1_2.5m_bio_1.tif"
  ))

template[which(!is.na(template[]))] <- 1


#reading and getting conversion table to use all files togethers
conversion_table <-
  readxl::read_xlsx(
    "E:/CSOSA/Dropbox/VAVILOV_2.0/Results/SUMMARY_FILES/PROJECT_STATUS.xlsx",
    "Hoja1"
  )