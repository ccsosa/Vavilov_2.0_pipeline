### this script can be used to obtain change maps from summary maps of future and current

# author: Chrystian Sosa

library(terra)
library(viridis)
library(sf)
library(foreach)
library(bit)
# library(ggplot2)
library(bit)
library(tidyterra)
require(leaflet)
library(htmlwidgets)
library(viridisLite)
library(ggplot2)
################################################################################
basedir <- "//catalogue/MultifLandscapesA1706"
adm0 <- vect(paste0(basedir, "/1.Data/RAW/input_data/adm0/adm0_Latam", ".shp"))

CC_dir <- "//catalogue/MultifLandscapesA1706/1.Data/Results/Summary_maps_folder_CC/TIF"
Current_dir <- "//catalogue/MultifLandscapesA1706/1.Data/Results/summary_maps_folder/TIF"
SSP <- c("ssp245","ssp370")
current <- terra::rast(paste0(Current_dir,"/","species_richness_current.tif"))
plot_dir <- "//catalogue/MultifLandscapesA1706/1.Data/Results/Summary_maps_folder_CC/PNG"
for(i in 1:2){
  # i <- 1
  future <- terra::rast(paste0(CC_dir,"/","species_richness_SDM_future_",SSP[[i]],".tif"))
  change <- future - current
  terra::writeRaster(change,paste0(CC_dir,"/","changes_",SSP[[i]],"_current.tif"),overwrite=T)
  #plotting current
  mn <- terra::global(change, "min",na.rm=T) [[1]]
  mx <- terra::global(change, "max",na.rm=T) [[1]]
  
  zero_pos <- (0-mn)/(mx-mn)

  
    # #numger of steps
  # n_neg <- 200
  # n_pos <- 200
  
  # col_neg <- colorRampPalette(c("red","yellow","white"))(n_neg)
  # col_pos <- colorRampPalette(c("white","#2166ac"))(n_pos)

  # all_cols <- c(col_neg,col_pos)
  # 
  # breaks_neg <- seq(mn,0,lenght.out=n_neg+1)
  # breaks_pos <- seq(0,mx,lenght.out=n_pos+1)
  # all_breaks <- c(breaks_neg,breaks_pos[-1])


  # mypal <- colorRampPalette(c("red","yellow","blue"))(20)
  # message("Making a plot")
  # 
  #Plotting
  # setwd(dir = paste0(plot_dir))
  # png(paste0("LATAM_Edible_food_","changes_",SSP[[i]], ".png"), width = 10, height = 10,
  #     units = "in",   # interpret as inches
  #     res = 1000)      # 300 dpi = print quality
  
  par(mfrow = c(1,1))
  par(mai = c(0.5, 0.5, 0.5, 0.5))

  p <- ggplot()+
    geom_spatraster(data=change) +
    scale_fill_gradientn(
    colours = c("red","yellow","white","#2166ac"),
  values=c(0,zero_pos*0.85,zero_pos,1),
  na.value = "transparent",
  name = "species"
  ) +
  geom_sf(data=sf::st_as_sf(adm0),
          fill=NA,
          colour="grey17",
          linewidth=0.3 ) + 
  theme_void()+
  theme(legend.key.height=unit(2,"cm"),
        legend.key.width =unit(0.5,"cm"),
        plot.background = element_rect(fill="white",colour=NA))

  
  # dev.off()
ggsave(filename=paste0("LATAM_Edible_food_","changes_",SSP[[i]], ".png"),
       plot=p,
       width = 10,
       height = 10,
       units = "in",
       dpi=1000)
  
}
