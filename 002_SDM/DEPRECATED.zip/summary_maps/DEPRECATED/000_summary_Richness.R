### this script can be used to put the AUC values and thresholds of the
# calibrated models in a single table

# author: Chrystian Sosa

library(terra)
library(viridis)
library(sf)
library(bit)

user <- "Chrystian"
if(user == "Chrystian") {
  basedir <-  "/catalogue/MultifLandscapesA1706"
}
################################################################################
#get new function

CH_get_Raster_func <- function(A,B,InDir,conv_hull_dir,species_list){
  
  files_ch <- lapply(A,B,function(i){
    # message(i)
    
    if(file.exists(paste0(InDir,"/",species_list[[i]],".tif"))& 
       file.exists(paste0(conv_hull_dir,"/","convex hull ",species_list[[i]],".tif"))
    ){
      # get files
      x <- terra::rast(paste0(conv_hull_dir,"/","convex hull ",species_list[[i]],".tif"))
      #resampling
      x <- terra::resample(x,richness)
      x1 <- terra::rast(paste0(InDir,"/",species_list[[i]],".tif"))
      x <- x1*x
      # x2 <- x2+x
    } else {
      message(paste0(species_list[[i]]," is not available"))
      # # x1 <- x1
      x <- NULL
    }
    return(x)
  })
  files_ch <- terra::rast(files_ch)
  # #creating summary richness file
  richness <- sum(files_ch ,na.rm = T)
  return(richness)
}
#MaxEnt results
# resultdir <- "/catalogue/MultifLandscapesA1706/1.Data/Results/CWR_results"
resultdir <- "/catalogue/MultifLandscapesA1706/1.Data/Results/SDM results"

# set target region
summary_richness_function <- function(basedir,resultdir,future_proj){
  
  message("loading shapefile and metrics")
  adm0 <- vect(paste0(basedir, "/1.Data/RAW/input_data/adm0/adm0_Latam", ".shp"))
  #load metrics
  metrics <- read.csv(paste0(resultdir,"/","AUC_Maxent_valid.csv"))
  #gettting speies lists to get results
  species_list <- metrics$species
  species_list <- sub(pattern = "model_evaluation_",replacement = "",species_list)
  species_list <- sub(pattern = ".csv",replacement = "",species_list)
  print(length(species_list))
  species_list <- species_list[which(species_list!="Cabralea canjerana")]
  print(length(species_list))
  
  #adding presence absence results folder
  InDir <- paste0(resultdir,"/Distribution maps/Presence-absence")
  
  ################################################################################
  ####First step (summary file)
  
  
  if(!file.exists( paste0(resultdir,"/","species_richness_current.tif"))){
    
    
    message("doing summary for current")
    message("Reading all rasters from species list")
    #reading raster
    x <- terra::rast(paste0(InDir,"/",species_list[[1]],".tif"))
    # files_to <- lapply(2:length(species_list),function(i){
    for(i in 2:length(species_list)){
      
      if(file.exists(paste0(InDir,"/",species_list[[i]],".tif"))){
        x1 <- terra::rast(paste0(InDir,"/",species_list[[i]],".tif"))
        x <- x + x1
      } else {
        message(paste0(species_list[[i]]," is not available"))
        # x1 <- x1
        x <- x
      }
      # return(x)
      
      
    }
    
    message("Stacking, summarizing and saving outcome")
    # #stacking
    # files_to <- terra::rast(files_to)
    # #creating summary richness file
    # richness <- sum(files_to ,na.rm = T)
    # #removing 0
    richness <- x
    #saving tiff
    terra::writeRaster(richness,
                       filename = paste0(resultdir,"/","species_richness_current.tif"),
                       overwrite=T)
  } else {
    richness <- terra::rast(paste0(resultdir,"/","species_richness_current.tif"))
  } 
  
  # richness[which(richness[]==0)] <- NA
  
  
  message("Making a plot")
  
  #Plotting
  setwd(dir = paste0(resultdir))
  pdf(paste0("LATAM_Edible_food_","_species_richness_current", ".pdf"), width = 10, height = 10)
  par(mfrow = c(1,1))
  par(mai = c(0.5, 0.5, 0.5, 0.5))
  plot(richness,
       main="",
       #main = paste0("Species richness"),
       legend = T,
       col = viridis(length(species_list)))
  plot(sf::st_geometry(sf::st_as_sf(adm0)), add = TRUE, border = "grey17", lwd = 1.25)
  dev.off()
  
  ################################################################################
  ####Second step (summary file in convex hull!)
  conv_hull_dir <- paste0(resultdir,"/Convex hulls")
  
  # x <- terra::rast(paste0(conv_hull_dir,"/","convex hull ",species_list[[1]],".tif"))
  # x <- terra::resample(x,richness)
  # x1 <- terra::rast(paste0(InDir,"/",species_list[[1]],".tif"))
  # x <- x*x1
  # x2 <- x
  # # for(i in 2:length(species_list)){
  
  x_chunks <- bit::chunks(1,  length(species_list), by=1000) #200000
  sum_i_CH <- list()
  for(i in 1:length(x_chunks)){
    #get limits
    A <- as.numeric(as.character(x_chunks[[i]])[1])
    B <- as.numeric(as.character(x_chunks[[i]])[2])
    
    sum_i_CH[[i]] <- CH_get_Raster_func(A,B,InDir,conv_hull_dir,species_list)
  }
    
  sum_i_CH <- terra::rast(sum_i_CH)
  richness_ch <- terra::sum(richness_ch,na.rm = T)
  richness_ch[which(richness_ch[]==0)] <- NA
  #saving tiff
  terra::writeRaster(richness_ch,
                     filename = paste0(resultdir,"/","CH_species_richness_current.tif"),
                     overwrite=T)
  
  message("Making a plot")
  
  #Plotting
  setwd(dir = paste0(resultdir))
  pdf(paste0("Richness_CH_species_richness_current", ".pdf"), width = 10, height = 10)
  par(mfrow = c(1,1))
  par(mai = c(0.5, 0.5, 0.5, 0.5))
  plot(richness_ch,
       main="",
       # main = paste0(region, " Species richness"),
       legend = T,
       col = viridis(length(species_list)))
  plot(sf::st_geometry(sf::st_as_sf(adm0)), add = TRUE, border = "grey17", lwd = 1.25)
  dev.off()
  
  ################################################################################
  ################################################################################
  #FUTURE
  # 
  # message("doing summary for future")
  # FutDir <- paste0(resultdir,"/Distribution maps/Future/2050/Consensus maps")
  # 
  # ################################################################################
  # ####Third step (summary file)
  # message("Reading all rasters from species list")
  # #reading raster
  # files_to <- lapply(1:length(species_list),function(i){
  #   if(file.exists(paste0(FutDir,"/",species_list[[i]],".tif"))) {
  #     x <- terra::rast(paste0(FutDir,"/",species_list[[i]],".tif"))
  #     return(x)
  #   } else {
  #     message(species_list[[i]])
  #   }
  #   
  # })
  # message("Stacking, summarizing and saving outcome")
  # #stacking
  # files_to <- rast(files_to)
  # #creating summary richness file
  # richness <- sum(files_to ,na.rm = T)
  # #removing 0
  # richness[which(richness[]==0)] <- NA
  # #saving tiff
  # terra::writeRaster(richness,
  #                    filename = paste0(resultdir,"/","species_richness_future_2050.tif"),
  #                    overwrite=T)
  # 
  # message("Making a plot")
  # 
  # #Plotting
  # setwd(dir = paste0(resultdir))
  # pdf(paste0(region,"_species_richness_future", ".pdf"), width = 10, height = 10)
  # par(mfrow = c(1,1))
  # par(mai = c(0.5, 0.5, 0.5, 0.5))
  # plot(richness, main = paste0(region, " Species richness"),
  #      legend = T,
  #      col = viridis(length(species_list)))
  # plot(sf::st_geometry(sf::st_as_sf(adm0)), add = TRUE, border = "grey17", lwd = 1.25)
  # dev.off()
  # ################################################################################
  # ################################################################################
  # ####fourth step (summary file in convex hull for future!)
  # conv_hull_dir <- paste0(resultdir,"/Convex hulls")
  # files_to_ch <- lapply(1:length(species_list),function(i){
  #   # i <- 1
  #   x <- terra::rast(paste0(conv_hull_dir,"/","convex hull ",species_list[[i]],".tif"))
  #   x <- terra::resample(x,files_to[[i]])
  #   x <- files_to[[i]]*x
  #   return(x)
  # })
  # #stacking
  # files_to_ch <- rast(files_to_ch)
  # #creating summary richness file
  # richness_ch <- sum(files_to_ch ,na.rm = T)
  # #removing 0
  # richness_ch[which(richness_ch[]==0)] <- NA
  # #saving tiff
  # terra::writeRaster(richness_ch,
  #                    filename = paste0(resultdir,"/","CH_species_richness_future.tif"),
  #                    overwrite=T)
  # 
  # message("Making a plot")
  # 
  # #Plotting
  # setwd(dir = paste0(resultdir))
  # pdf(paste0(region,"_CH_species_richness_future", ".pdf"), width = 10, height = 10)
  # par(mfrow = c(1,1))
  # par(mai = c(0.5, 0.5, 0.5, 0.5))
  # plot(richness_ch, main = paste0(region, " Species richness"),
  #      legend = T,
  #      col = viridis(length(species_list)))
  # plot(sf::st_geometry(sf::st_as_sf(adm0)), add = TRUE, border = "grey17", lwd = 1.25)
  # dev.off()
  # 
  return("DONE!")
}


summary_richness_function(basedir,resultdir)
