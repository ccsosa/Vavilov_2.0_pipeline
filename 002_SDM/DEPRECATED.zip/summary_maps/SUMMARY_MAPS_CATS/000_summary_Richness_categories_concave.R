### this script can be used to put the AUC values and thresholds of the
# calibrated models in a single table

# author: Chrystian Sosa

library(terra)
library(viridis)
library(sf)
library(foreach)
library(bit)
require(leaflet)
library(viridisLite)

################################################################################

summary_richness_function <-
  function(basedir,
           column_name,
           resultdir,
           template_file,
           species_selected) {
    
    ##############################################################################
    output_dir        <- "//catalogue/MultifLandscapesA1706/1.Data/Results"
    out_dir           <- output_dir
    out_buffer_dir    <- paste0(out_dir, "/SDM_buffer_results_CONCAVE_HULL")
    if (!dir.exists(out_buffer_dir)) dir.create(out_buffer_dir)
    
    out_buffer_dir_summary <- paste0(out_buffer_dir, "/summary3")
    if (!dir.exists(out_buffer_dir_summary)) dir.create(out_buffer_dir_summary)
    
    out_buffer_dir_summary_png   <- paste0(out_buffer_dir_summary, "/PNG")
    out_buffer_dir_summary_tif   <- paste0(out_buffer_dir_summary, "/TIF")
    out_buffer_dir_summary_html  <- paste0(out_buffer_dir_summary, "/HTML")
    
    message(out_buffer_dir_summary)
    
    if (!dir.exists(out_buffer_dir_summary_png))  dir.create(out_buffer_dir_summary_png)
    if (!dir.exists(out_buffer_dir_summary_tif))  dir.create(out_buffer_dir_summary_tif)
    if (!dir.exists(out_buffer_dir_summary_html)) dir.create(out_buffer_dir_summary_html)
    
    out_buffer_dir_summary_chunks <- paste0(out_buffer_dir_summary, "/chunks")
    if (!dir.exists(out_buffer_dir_summary_chunks)) dir.create(out_buffer_dir_summary_chunks)
    
    conv_dir <- paste0(basedir, "/1.Data/Results/concave_hull_rasters_SDM")
    
    ################################################################################
    message(paste0("Step 4... Getting categories for ", column_name))
    
    categories <- unique(species_selected[, c(column_name)])
    categories <- categories[!categories %in% c(NA, "TO FILL", "N/A", "?")]
    print(categories)
    
    ################################################################################
    template <- terra::rast(template_file)
    template[which(!is.na(template[]))] <- 1
    
    message("loading shapefile and metrics")
    species_total <- unique(species_selected$species)
    
    ##############################################################################
    InDir_buffer        <- "//catalogue/MultifLandscapesA1706/1.Data/Results/buffer_richness/raster"
    sp_buffer_list      <- list.files(InDir_buffer, pattern = ".tif")
    sp_buffer_list_name <- sub(pattern = ".tif", replacement = "", sp_buffer_list)
    
    ##############################################################################
    metrics      <- read.csv(paste0(resultdir, "/", "AUC_Maxent_valid_ALL.csv"))
    species_list <- metrics$species
    species_list <- sub(pattern = "model_evaluation_", replacement = "", species_list)
    species_list <- sub(pattern = ".csv",               replacement = "", species_list)
    
    avail_sp_modeled <- species_list[species_list %in% species_total]
    
    ##############################################################################
    buffer_sps <- species_total[!species_total %in% avail_sp_modeled]
    buffer_sps <- buffer_sps[buffer_sps %in% sp_buffer_list_name]
    
    ##############################################################################
    InDir <- paste0(resultdir, "/Distribution maps/Presence-absence")
    
    ################################################################################
    for (i in 1:length(categories)) {
      
      adm0 <- terra::vect(paste0(basedir, "/1.Data/RAW/input_data/adm0/adm0_Latam", ".shp"))
      
      category <- categories[[i]]
      if (category == "fruits?") {
        category_name <- "fruits_dubius"
      } else if (category == "pulses?") {
        category_name <- "pulses_dubius"
      } else if (category == "oil/fats") {
        category_name <- "oil_fats"
      } else if (category == "gums/mucilages") {
        category_name <- "gums_mucilages"
      } else if (category == "root/tuber vegetables") {
        category_name <- "roots"
      } else if (category == "other food types") {
        category_name <- "other_food_types"
      } else if (category == "food additive") {
        category_name <- "food_additive"
      } else if (category == "sugar and syrups") {
        category_name <- "sugar_and_syrups"
      } else if (category == "nuts and seeds") {
        category_name <- "nuts_and_seeds"
      } else if (category == "Non-woody epiphyte") {
        category_name <- "NW_epiphyte"
      } else if (category == "unspecified aerial parts") {
        category_name <- "UAP"
      } else if (category == "seedlings/germinated seed") {
        category_name <- "SG"
      } else {
        category_name <- category
      }
      
      message(paste0("starting ", category))
      
      ################################################################################
      species_subsetted    <- species_selected[which(species_selected[, column_name] == category), ]
      avail_sp_modeled_i   <- species_subsetted[species_subsetted$species %in% avail_sp_modeled, ]
      avail_sp_modeled_i   <- data.frame(species = unique(avail_sp_modeled_i$species))
      buffer_sps_i         <- species_subsetted[species_subsetted$species %in% buffer_sps, ]
      buffer_sps_i         <- data.frame(species = unique(buffer_sps_i$species))
      
      ################################################################################
      if (!file.exists(paste0(out_buffer_dir_summary_tif, "/", column_name, "_", category_name, "_richness_current.tif"))) {
        
        ##?????? SDM richness ???????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????
        if (!file.exists(paste0(out_buffer_dir_summary_tif, "/", column_name, "_", category_name, "_SDM_richness_current.tif"))) {
          
          message("Checking file availability...")
          valid_paths <- do.call(rbind, lapply(avail_sp_modeled_i$species, function(sp) {
            sdm_path  <- paste0(InDir,    "/", sp, ".tif")
            conv_path <- paste0(conv_dir, "/", sp, "_conc.tif")
            if (!file.exists(sdm_path)) return(NULL)
            data.frame(
              sdm  = sdm_path,
              conv = ifelse(file.exists(conv_path), conv_path, NA_character_),
              stringsAsFactors = FALSE
            )
          }))
          
          if (is.null(valid_paths) || nrow(valid_paths) == 0) {
            message("No valid SDM rasters found.")
            richness <- NULL
          } else {
            message(paste0(nrow(valid_paths), " valid SDM rasters found."))
            message(paste0(sum(!is.na(valid_paths$conv)), " have concave hull."))
            
            chunk_size <- if (nrow(valid_paths) < 10) nrow(valid_paths) else 10
            chunk_idx  <- split(seq_len(nrow(valid_paths)),
                                ceiling(seq_len(nrow(valid_paths)) / chunk_size))
            n_chunks   <- length(chunk_idx)
            message(paste0("Processing ", n_chunks, " chunks of up to ", chunk_size, " rasters..."))
            
            n_cores <- 4
            cl      <- parallel::makeCluster(n_cores)
            doParallel::registerDoParallel(cl)
            message(paste0("Using ", n_cores, " cores for ", n_chunks, " chunks"))
            
            chunk_dir <- paste0(out_buffer_dir_summary_chunks, "/chunks2")
            if (!dir.exists(chunk_dir)) dir.create(chunk_dir)
            
            chunk_results <- foreach::foreach(
              chunk          = chunk_idx,
              .packages      = "terra",
              .errorhandling = "pass"
            ) %dopar% {
              rows_chunk <- valid_paths[chunk, ]
              chunk_id   <- chunk[1]
              
              masked_list <- lapply(seq_len(nrow(rows_chunk)), function(j) {
                sdm <- terra::rast(rows_chunk$sdm[j])
                if (!is.na(rows_chunk$conv[j])) {
                  conv <- terra::rast(rows_chunk$conv[j])
                  conv <- terra::resample(conv, sdm, method = "near")
                  sdm  <- sdm * conv
                }
                sdm
              })
              
              stack  <- terra::rast(masked_list)
              result <- terra::app(stack, fun = "sum", na.rm = TRUE)
              
              out_path <- paste0(chunk_dir, "/chunk_", sprintf("%04d", chunk_id), ".tif")
              terra::writeRaster(result, filename = out_path, overwrite = TRUE)
              out_path
            }
            
            parallel::stopCluster(cl)
            
            failed <- sapply(chunk_results, inherits, "error")
            if (any(failed)) {
              message(paste0(sum(failed), " chunk(s) failed:"))
              print(chunk_results[failed])
              stop("Aborting: fix failed chunks before proceeding.")
            }
            
            message("Combining chunk results into final richness raster...")
            chunk_paths <- unlist(chunk_results)
            chunk_stack <- terra::rast(chunk_paths)
            x           <- terra::app(chunk_stack, fun = "sum", na.rm = TRUE)
            
            message("Saving SDM_richness_current.tif ...")
            terra::writeRaster(
              x,
              filename  = paste0(out_buffer_dir_summary_tif, "/", column_name, "_", category_name, "_SDM_richness_current.tif"),
              overwrite = TRUE
            )
            
            message("Cleaning up chunk files...")
            file.remove(chunk_paths)
            unlink(chunk_dir)
            richness <- x
            message("Done!")
          }
          
        } else {
          richness <- terra::rast(
            paste0(out_buffer_dir_summary_tif, "/", column_name, "_", category_name, "_SDM_richness_current.tif")
          )
        }
        
        ##?????? Buffer richness ??????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????
        message("Doing for buffer")
        if (!file.exists(paste0(out_buffer_dir_summary_tif, "/", column_name, "_", category_name, "_buffer_richness_current.tif"))) {
          
          message("Checking file availability...")
          valid_paths <- do.call(rbind, lapply(buffer_sps_i$species, function(sp) {
            sdm_path  <- paste0(InDir_buffer, "/", sp, ".tif")
            conv_path <- paste0(conv_dir,     "/", sp, "_conc.tif")
            if (!file.exists(sdm_path)) return(NULL)
            data.frame(
              sdm  = sdm_path,
              conv = ifelse(file.exists(conv_path), conv_path, NA_character_),
              stringsAsFactors = FALSE
            )
          }))
          
          if (is.null(valid_paths) || nrow(valid_paths) == 0) {
            message("No valid buffer rasters found.")
            richness_buffer <- NULL
          } else {
            message(paste0(nrow(valid_paths), " valid buffer rasters found."))
            message(paste0(sum(!is.na(valid_paths$conv)), " have concave hull."))
            
            chunk_size <- if (nrow(valid_paths) < 10) nrow(valid_paths) else 10
            chunk_idx  <- split(seq_len(nrow(valid_paths)),
                                ceiling(seq_len(nrow(valid_paths)) / chunk_size))
            n_chunks   <- length(chunk_idx)
            message(paste0("Processing ", n_chunks, " chunks of up to ", chunk_size, " rasters..."))
            
            n_cores <- 4
            cl      <- parallel::makeCluster(n_cores)
            doParallel::registerDoParallel(cl)
            message(paste0("Using ", n_cores, " cores for ", n_chunks, " chunks"))
            
            chunk_dir <- paste0(out_buffer_dir_summary_tif, "/chunks2")
            if (!dir.exists(chunk_dir)) dir.create(chunk_dir)
            
            chunk_results <- foreach::foreach(
              chunk          = chunk_idx,
              .packages      = "terra",
              .errorhandling = "pass"
            ) %dopar% {
              rows_chunk <- valid_paths[chunk, ]
              chunk_id   <- chunk[1]
              
              masked_list <- lapply(seq_len(nrow(rows_chunk)), function(j) {
                sdm <- terra::rast(rows_chunk$sdm[j])
                if (!is.na(rows_chunk$conv[j])) {
                  conv <- terra::rast(rows_chunk$conv[j])
                  conv <- terra::resample(conv, sdm, method = "near")
                  sdm  <- sdm * conv
                }
                sdm
              })
              
              stack  <- terra::rast(masked_list)
              result <- terra::app(stack, fun = "sum", na.rm = TRUE)
              
              out_path <- paste0(chunk_dir, "/chunk_", sprintf("%04d", chunk_id), ".tif")
              terra::writeRaster(result, filename = out_path, overwrite = TRUE)
              out_path
            }
            
            parallel::stopCluster(cl)
            
            failed <- sapply(chunk_results, inherits, "error")
            if (any(failed)) {
              message(paste0(sum(failed), " chunk(s) failed:"))
              print(chunk_results[failed])
              stop("Aborting: fix failed chunks before proceeding.")
            }
            
            message("Combining chunk results into final richness raster...")
            chunk_paths <- unlist(chunk_results)
            chunk_stack <- terra::rast(chunk_paths)
            x           <- terra::app(chunk_stack, fun = "sum", na.rm = TRUE)
            
            message("Saving buffer_richness_current.tif ...")
            terra::writeRaster(
              x,
              filename  = paste0(out_buffer_dir_summary_tif, "/", column_name, "_", category_name, "_buffer_richness_current.tif"),
              overwrite = TRUE
            )
            
            message("Cleaning up chunk files...")
            file.remove(chunk_paths)
            unlink(chunk_dir)
            richness_buffer <- x
            message("Done!")
          }
          
        } else {
          richness_buffer <- terra::rast(
            paste0(out_buffer_dir_summary_tif, "/", column_name, "_", category_name, "_buffer_richness_current.tif")
          )
        }
        
        ##?????? Combine SDM + buffer ???????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????
        richness_res <- richness
        
        if (!is.null(richness_res) & !is.null(richness_buffer)) {
          message("SDM AVAIL, BUFFER AVAIL")
          richness_buffer_res <- terra::resample(richness_buffer, template, method = "near")
          richness_total      <- sum(richness_res, richness_buffer_res, na.rm = TRUE)
          terra::writeRaster(
            richness_total,
            filename  = paste0(out_buffer_dir_summary_tif, "/", column_name, "_", category_name, "_richness_current.tif"),
            overwrite = TRUE
          )
          
        } else if (is.null(richness_res) & !is.null(richness_buffer)) {
          message("NO SDM, BUFFER AVAIL")
          richness_buffer_res <- terra::resample(richness_buffer, template, method = "near")
          richness_total      <- richness_buffer_res
          terra::writeRaster(
            richness_total,
            filename  = paste0(out_buffer_dir_summary_tif, "/", column_name, "_", category_name, "_richness_current.tif"),
            overwrite = TRUE
          )
          
        } else if (!is.null(richness_res) & is.null(richness_buffer)) {
          message("SDM AVAIL, NO BUFFER")
          richness_total <- richness_res
          terra::writeRaster(
            richness_total,
            filename  = paste0(out_buffer_dir_summary_tif, "/", column_name, "_", category_name, "_richness_current.tif"),
            overwrite = TRUE
          )
          
        } else {
          message("NO FILE TO MAP")
          richness_total <- NULL
        }
        
      } else {
        richness_total <- terra::rast(
          paste0(out_buffer_dir_summary_tif, "/", column_name, "_", category_name, "_richness_current.tif")
        )
      }
      
      ################################################################################
      if (!is.null(richness_total)) {
        richness_total[which(richness_total[] == 0)] <- NA
        
        ##?????? PNG plot ?????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????
        message("Making a plot")
        par(mar = c(1, 1, 1, 1))
        setwd(dir = out_buffer_dir_summary_png)
        
        adm0_sf <- sf::st_as_sf(adm0)
        rm(adm0)
        
        png(
          paste0("LATAM_Edible_food_", column_name, "_", category_name, "_species_richness_current.png"),
          width = 10, height = 10, units = "in", res = 1000
        )
        par(mfrow = c(1, 1))
        par(mai = c(0.5, 0.5, 0.5, 0.5))
        plot(richness_total, main = "", legend = TRUE, col = viridis(length(species_list)))
        plot(sf::st_geometry(adm0_sf), add = TRUE, border = "grey17", lwd = 1.25)
        dev.off()
        
        ##?????? Leaflet HTML ?????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????
        message(paste("Step 5.9: HTML file step ", category))
        
        richness_total_rl <- raster::raster(
          paste0(out_buffer_dir_summary_tif, "/", column_name, "_", category_name, "_richness_current.tif")
        )
        richness_total_rl[which(richness_total_rl[] == 0)] <- NA
        
        raster_values <- raster::values(richness_total_rl)
        raster_values <- raster_values[!is.na(raster_values)]
        
        message(paste("Step 5.9.1: HTML breaks ", category))
        
        breaks <- quantile(
          raster_values,
          probs = seq(0, 0.9, length.out = num_classes + 1),
          na.rm = TRUE
        )
        breaks <- unique(breaks)
        
        if (length(breaks) < 2) {
          unique_val         <- breaks[1]
          breaks             <- c(unique_val - 0.5, unique_val + 0.5)
          colors             <- "red"
          actual_num_classes <- 1
          auto_labels        <- as.character(unique_val)
        } else {
          actual_num_classes <- length(breaks) - 1
          colors             <- turbo(actual_num_classes)
          auto_labels        <- sapply(seq_len(actual_num_classes), function(i) {
            lo <- breaks[i]
            hi <- breaks[i + 1]
            if (i == actual_num_classes) {
              paste0(">", lo)
            } else if (lo == hi - 1 || lo == hi) {
              as.character(lo)
            } else {
              paste0(lo, "-", hi - 1)
            }
          })
        }
        
        message(paste("Step 5.9.3: HTML colours ", category))
        
        pal <- colorBin(
          palette  = colors,
          domain   = range(raster_values),
          bins     = breaks,
          na.color = "transparent"
        )
        
        x <- leaflet() %>%
          addTiles() %>%
          addProviderTiles(providers$CartoDB.Positron) %>%
          addMiniMap(width = 150, height = 150) %>%
          addRasterImage(
            richness_total_rl,
            colors   = pal,
            opacity  = 0.3,
            project  = T,
            maxBytes = 20 * 1024 ^ 2
          ) %>%
          addLegend(
            pal       = pal,
            values    = range(raster_values),
            title     = "Species Richness",
            labFormat = function(type, cuts, p) auto_labels
          )
        
        message(paste("Step 5.9.4: HTML saving ", category))
        htmlwidgets::saveWidget(
          x,
          paste0(out_buffer_dir_summary_html, "/", column_name, "_", category_name, "_SDM_buffer_richness.html"),
          selfcontained = FALSE
        )
        message(paste("DONE: ", category))
        
      } else {
        message(paste0("skipping... ", category))
      }
    }
    return("DONE!")
  }

################################################################################
user <- "Chrystian"
if (user == "Chrystian") {
  basedir <- "//catalogue/MultifLandscapesA1706"
}

resultdir <- "//catalogue/MultifLandscapesA1706/1.Data/Results/SDM results"

species_selected <- as.data.frame(
  readxl::read_xlsx(
    "//catalogue/MultifLandscapesA1706/1.Data/Results/species_lists/species_curated/Species_20250304_edible_part_curated.xlsx",
    col_names = TRUE
  )
)
species_selected$all <- 1

template_file <- paste0(
  "//catalogue/MultifLandscapesA1706/1.Data/RAW/Input_data/climate_data/2_5min/present/",
  "wc2.1_2.5m_bio_1.tif"
)

num_classes <- 8

column_name <- "plant_status"
summary_richness_function(basedir, column_name, resultdir, template_file, species_selected)

column_name <- "plant_part"
summary_richness_function(basedir, column_name, resultdir, template_file, species_selected)

column_name <- "all"
summary_richness_function(basedir, column_name, resultdir, template_file, species_selected)

column_name <- "food_group_to_map"
summary_richness_function(basedir, column_name, resultdir, template_file, species_selected)