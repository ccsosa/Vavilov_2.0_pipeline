### this script can be used to put the AUC values and thresholds of the
# calibrated models in a single table

# author: Chrystian Sosa

library(terra)
library(viridis)
library(sf)
library(foreach)
library(bit)
# library(ggplot2)
library(bit)
require(leaflet)
library(htmlwidgets)
library(viridisLite)
################################################################################
#get new function
CH_get_Raster_func <- function(A, B, InDir, conv_hull_dir, species_list){
  
  files_ch <- lapply(A:B, function(i){   # <-- fixed: A:B instead of A, B
    # message(i)
    
    if(file.exists(paste0(InDir, "/", species_list[[i]], ".tif")) & 
       file.exists(paste0(conv_hull_dir, "/", "convex hull ", species_list[[i]], ".tif"))
    ){
      x  <- terra::rast(paste0(conv_hull_dir, "/", "convex hull ", species_list[[i]], ".tif"))
      x  <- terra::resample(x, template, method = "near")
      x1 <- terra::rast(paste0(InDir, "/", species_list[[i]], ".tif"))
      x  <- x1 * x
    } else {
      message(paste0(species_list[[i]], " is not available"))
      x <- NULL
    }
    return(x)
  })
  
  # Remove NULLs before stacking (missing species will break terra::rast)
  files_ch <- Filter(Negate(is.null), files_ch)
  
  files_ch <- terra::rast(files_ch)
  richness <- sum(files_ch, na.rm = TRUE)
  return(richness)
}
#MaxEnt results
# resultdir <- "/catalogue/MultifLandscapesA1706/1.Data/Results/CWR_results"
resultdir <- "/catalogue/MultifLandscapesA1706/1.Data/Results/SDM results"

# set target region
summary_richness_function <- function(basedir,resultdir,template,species_selected,num_classes){
  ##############################################################################
  #config adding a results_dir
  output_dir <- "/catalogue/MultifLandscapesA1706/1.Data/Results"
  # chunks summary_dir
  output_dir_maps  <-
    paste0(output_dir, "/SDM_buffer_results_all")
  if (!dir.exists(output_dir_maps)) {
    dir.create(output_dir_maps)
  }
  
  output_dir_maps_PNG  <-
    paste0(output_dir_maps, "/PNG")
  if (!dir.exists(output_dir_maps_PNG)) {
    dir.create(output_dir_maps_PNG)
  }
  output_dir_maps_TIF  <-
    paste0(output_dir_maps, "/TIF")
  if (!dir.exists(output_dir_maps_TIF)) {
    dir.create(output_dir_maps_TIF)
  }
  output_dir_maps_HTML  <-
    paste0(output_dir_maps, "/HTML")
  if (!dir.exists(output_dir_maps_HTML)) {
    dir.create(output_dir_maps_HTML)
  }  
  
  output_dir_chunks  <-
    paste0(output_dir_maps, "/chunks")
  if (!dir.exists(output_dir_chunks)) {
    dir.create(output_dir_chunks)
  }  
  
  
  ##############################################################################
  #loading adm0
  message("loading shapefile and metrics")
  adm0 <- vect(paste0(basedir, "/1.Data/RAW/input_data/adm0/adm0_Latam", ".shp"))
  #all species
  species_total <- unique(species_selected$species)
  ##############################################################################
  #loading buffer species
  InDir_buffer <- "/catalogue/MultifLandscapesA1706/1.Data/Results/buffer_richness/raster"
  #species with buffer
  sp_buffer_list <- list.files(InDir_buffer,pattern = ".tif")
  sp_buffer_list_name <- sub(pattern = ".tif",replacement = "",sp_buffer_list)
  ##############################################################################
  #load metrics to get modeled species
  metrics <- read.csv(paste0(resultdir,"/","AUC_Maxent_valid.csv"))
  #gettting species lists to get results (modeled species with MaxEnt)
  species_list <- metrics$species
  species_list <- sub(pattern = "model_evaluation_",replacement = "",species_list)
  species_list <- sub(pattern = ".csv",replacement = "",species_list)
  # print(length(species_list))
  # species_list <- species_list[which(species_list!="Cabralea canjerana")]
  # print(length(species_list))
  #species with valid model
  avail_sp_modeled <- species_list[species_list %in% species_total]
  ##############################################################################
  #species with buffer
  # buffer_sps <- species_total[sp_buffer_list_name %in% species_total]
  buffer_sps <- species_total[!species_total %in% avail_sp_modeled] 
  #if buffer_sps + avail_sp_modeled =8221 is well done!
  buffer_sps <- buffer_sps[buffer_sps %in% sp_buffer_list_name] #available to use buffer
  ##############################################################################
  #adding presence absence results folder
  InDir <- paste0(resultdir,"/Distribution maps/Presence-absence")
  ################################################################################
  ####First step (summary file)
  
  
  # if(!file.exists( paste0(output_dir_maps_TIF,"/","species_richness_current.tif"))){
    
    message("doing summary for current")
    message("Reading all rasters from species list")
    
  if(!file.exists(paste0(output_dir_maps_TIF, "/", "species_richness_current.tif"))) {
      
    if(!file.exists(paste0(output_dir_maps_TIF, "/", "species_richness_SDM_current.tif"))) {
      
      message("Doing summary for current (parallel chunked mode)")
      
      # --- 1. Validate paths sequentially ---------------------------------------
      message("Checking file availability...")
      valid_paths <- vapply(avail_sp_modeled, function(sp) {
        path <- paste0(InDir, "/", sp, ".tif")
        if (file.exists(path)) path else NA_character_
      }, character(1))
      
      missing_sps <- avail_sp_modeled[is.na(valid_paths)]
      valid_paths <- valid_paths[!is.na(valid_paths)]
      
      if (length(missing_sps) > 0)
        message(paste0(length(missing_sps), " species raster(s) not found and skipped."))
      message(paste0(length(valid_paths), " valid rasters found."))
      
      # --- 2. Split into chunks of 100 ------------------------------------------
      chunk_size <- 15
      chunk_idx  <- split(seq_along(valid_paths),
                          ceiling(seq_along(valid_paths) / chunk_size))
      n_chunks   <- length(chunk_idx)
      message(paste0("Processing ", n_chunks, " chunks of up to ", chunk_size, " rasters..."))
      
      # --- 3. Setup parallel backend --------------------------------------------
      n_cores <- 8 #min(parallel::detectCores() - 2, n_chunks)
      cl      <- parallel::makeCluster(n_cores)
      doParallel::registerDoParallel(cl)
      message(paste0("Using ", n_cores, " cores for ", n_chunks, " chunks"))
      
      # --- Create chunks subfolder ----------------------------------------------
      chunk_dir <- paste0(output_dir_maps_TIF, "/chunks")
      if (!dir.exists(chunk_dir)) dir.create(chunk_dir)
      
      # --- 4. Parallel chunk summation with NA → 0 ------------------------------
      chunk_results <- foreach::foreach(
        chunk          = chunk_idx,
        .packages      = "terra",
        .errorhandling = "pass"
      ) %dopar% {
        
        paths_chunk <- valid_paths[chunk]
        chunk_id    <- chunk[1]  # use first index as unique chunk identifier
        
        stack  <- terra::rast(paths_chunk)
        result <- terra::app(stack, fun = "sum", na.rm = TRUE)
        
        # Save to known folder with predictable name
        out_path <- paste0(chunk_dir, "/chunk_", sprintf("%04d", chunk_id), ".tif")
        terra::writeRaster(result, filename = out_path, overwrite = TRUE)
        out_path
      }
      
      parallel::stopCluster(cl)
      
      # --- 5. Check for chunk errors --------------------------------------------
      failed <- sapply(chunk_results, inherits, "error")
      if (any(failed)) {
        message(paste0(sum(failed), " chunk(s) failed:"))
        print(chunk_results[failed])
        stop("Aborting: fix failed chunks before proceeding.")
      }
      
      # --- 6. Final sum across chunk files --------------------------------------
      message("Combining chunk results into final richness raster...")
      chunk_paths <- unlist(chunk_results)
      chunk_stack <- terra::rast(chunk_paths)
      x           <- terra::app(chunk_stack, fun = "sum", na.rm = TRUE)
      
      # --- 7. Save final raster -------------------------------------------------
      message("Saving species_richness_current.tif ...")
      terra::writeRaster(
        x,
        filename  = paste0(output_dir_maps_TIF, "/", "species_richness_SDM_current.tif"),
        overwrite = TRUE
      )
      
      # --- 8. Cleanup chunks folder ---------------------------------------------
      message("Cleaning up chunk files...")
      file.remove(chunk_paths)
      unlink(chunk_dir)
      richness <- x
      message("Done!")
    } else {
      richness <- terra::rast(paste0(output_dir_maps_TIF, "/", "species_richness_current.tif"))
      
    }
    ################################################################################
    #creating for buffer
    message("Doing for buffer")
    if(!file.exists(paste0(output_dir_maps_TIF, "/", "species_richness_buffer_current.tif"))) {
      
      message("Doing summary for current (parallel chunked mode)")
      
      # --- 1. Validate paths sequentially ---------------------------------------
      message("Checking file availability...")
      valid_paths <- vapply(buffer_sps, function(sp) {
        path <- paste0(InDir_buffer, "/", sp, ".tif")
        if (file.exists(path)) path else NA_character_
      }, character(1))
      
      missing_sps <- buffer_sps[is.na(valid_paths)]
      valid_paths <- valid_paths[!is.na(valid_paths)]
      
      if (length(missing_sps) > 0)
        message(paste0(length(missing_sps), " species raster(s) not found and skipped."))
      message(paste0(length(valid_paths), " valid rasters found."))
      
      # --- 2. Split into chunks of 100 ------------------------------------------
      chunk_size <- 15
      chunk_idx  <- split(seq_along(valid_paths),
                          ceiling(seq_along(valid_paths) / chunk_size))
      n_chunks   <- length(chunk_idx)
      message(paste0("Processing ", n_chunks, " chunks of up to ", chunk_size, " rasters..."))
      
      # --- 3. Setup parallel backend --------------------------------------------
      n_cores <- 8 #min(parallel::detectCores() - 2, n_chunks)
      cl      <- parallel::makeCluster(n_cores)
      doParallel::registerDoParallel(cl)
      message(paste0("Using ", n_cores, " cores for ", n_chunks, " chunks"))
      
      # --- Create chunks subfolder ----------------------------------------------
      chunk_dir <- paste0(output_dir_maps_TIF, "/chunks")
      if (!dir.exists(chunk_dir)) dir.create(chunk_dir)
      
      # --- 4. Parallel chunk summation with NA → 0 ------------------------------
      chunk_results <- foreach::foreach(
        chunk          = chunk_idx,
        .packages      = "terra",
        .errorhandling = "pass"
      ) %dopar% {
        
        paths_chunk <- valid_paths[chunk]
        chunk_id    <- chunk[1]  # use first index as unique chunk identifier
        
        stack  <- terra::rast(paths_chunk)
        result <- terra::app(stack, fun = "sum", na.rm = TRUE)
        
        # Save to known folder with predictable name
        out_path <- paste0(chunk_dir, "/chunk_", sprintf("%04d", chunk_id), ".tif")
        terra::writeRaster(result, filename = out_path, overwrite = TRUE)
        out_path
      }
      
      parallel::stopCluster(cl)
      
      # --- 5. Check for chunk errors --------------------------------------------
      failed <- sapply(chunk_results, inherits, "error")
      if (any(failed)) {
        message(paste0(sum(failed), " chunk(s) failed:"))
        print(chunk_results[failed])
        stop("Aborting: fix failed chunks before proceeding.")
      }
      
      # --- 6. Final sum across chunk files --------------------------------------
      message("Combining chunk results into final richness raster...")
      chunk_paths <- unlist(chunk_results)
      chunk_stack <- terra::rast(chunk_paths)
      x           <- terra::app(chunk_stack, fun = "sum", na.rm = TRUE)
      
      # --- 7. Save final raster -------------------------------------------------
      message("Saving species_richness_buffer_current.tif ...")
      terra::writeRaster(
        x,
        filename  = paste0(output_dir_maps_TIF, "/", "species_richness_buffer_current.tif"),
        overwrite = TRUE
      )
      richness_buffer <- x
      # --- 8. Cleanup chunks folder ---------------------------------------------
      message("Cleaning up chunk files...")
      file.remove(chunk_paths)
      unlink(chunk_dir)
      message("Done!")
    } else {
      richness_buffer <- terra::rast(paste0(output_dir_maps_TIF, "/", "species_richness_buffer_current.tif"))
      
    }
    
    
    richness_res <- richness #terra::resample(richness,template,method="near")
    richness_buffer_res <- terra::resample(richness_buffer,template,method="near")
    # richness_total <- richness_res + richness_buffer_res
    richness_total <- sum(richness_res,richness_buffer_res,na.rm = T)
    
    terra::writeRaster(
      richness_total,
      filename  = paste0(output_dir_maps_TIF, "/", "species_richness_current.tif"),
      overwrite = TRUE
    )
} else {
  richness_total <- terra::rast(paste0(output_dir_maps_TIF, "/", "species_richness_current.tif"))
}
    
    
    ################################################################################
    ################################################################################
    ################################################################################
    ################################################################################
  message("Making a plot")
  
  #Plotting
  par(mar = c(1, 1, 1, 1))
    
  setwd(dir = paste0(output_dir_maps_PNG))
  png(paste0("LATAM_Edible_food_","_species_richness_current", ".png"), width = 10, height = 10,
      units = "in",   # interpret as inches
      res = 1000)      # 300 dpi = print quality
  par(mfrow = c(1,1))
  par(mai = c(0.5, 0.5, 0.5, 0.5))
  plot(richness_total,
       main="",
       #main = paste0("Species richness"),
       legend = T,
       col = viridis(length(species_list)))
  plot(sf::st_geometry(sf::st_as_sf(adm0)), add = TRUE, border = "grey17", lwd = 1.25)
  dev.off()
  ################################################################################
  ####Second step (summary file in convex hull!)
  conv_hull_dir <- paste0(resultdir,"/Convex hulls")
  
  # x <- terra::rast(paste0(conv_hull_dir,"/","convex hull ",species_list[[1]],".tif"))
  # x <- terra::resample(x,richness)
  # x1 <- terra::rast(paste0(InDir,"/",species_list[[1]],".tif"))
  # x <- x*x1
  # x2 <- x
  # # for(i in 2:length(species_list)){
  if(!file.exists(paste0(resultdir,"/","CH_species_richness_buffer_current.tif"))){
  x_chunks <- bit::chunks(1,  length(avail_sp_modeled), by=100) #200000
  sum_i_CH <- list()
  for(i in 1:length(x_chunks)){
    #get limits
    A <- as.numeric(as.character(x_chunks[[i]])[1])
    B <- as.numeric(as.character(x_chunks[[i]])[2])
    
    sum_i_CH[[i]] <- 
      CH_get_Raster_func(A,B,InDir,conv_hull_dir,avail_sp_modeled)
  }
    
  sum_i_CH <- terra::rast(sum_i_CH)
  richness_ch <- sum(sum_i_CH,na.rm = T)
  richness_ch[which(richness_ch[]==0)] <- NA
  #saving tiff
  terra::writeRaster(richness_ch,
                     filename = paste0(resultdir,"/","CH_species_richness_current.tif"),
                     overwrite=T)
  
  ###including buffer
  richness_buffer_res <- terra::resample(richness_buffer,template,method="near")
  
  # richness_ch_total <- richness_buffer_res + richness_ch
  richness_ch_total <- sum(richness_buffer_res,richness_ch,na.rm = T)
  
  
  terra::writeRaster(richness_ch_total,
                     filename = paste0(resultdir,"/","CH_species_richness_buffer_current.tif"),
                     overwrite=T)
  } else {
    richness_ch_total <- terra::rast(paste0(resultdir,"/","CH_species_richness_buffer_current.tif"))
  }
  
  
  
  message("Making a plot")
  
  #Plotting
  setwd(dir = paste0(resultdir))
  # pdf(paste0("Richness_CH_species_richness_current", ".pdf"), width = 10, height = 10)
  png(paste0("LATAM_Edible_food_","_species_richness_convex_hull_current", ".png"), width = 10, height = 10,
      units = "in",   # interpret as inches
      res = 1000)      # 300 dpi = print quality
  par(mfrow = c(1,1))
  par(mai = c(0.5, 0.5, 0.5, 0.5))
  plot(richness_ch_total,
       main="",
       # main = paste0(region, " Species richness"),
       legend = T,
       col = viridis(length(species_list)))
  plot(sf::st_geometry(sf::st_as_sf(adm0)), add = TRUE, border = "grey17", lwd = 1.25)
  dev.off()
  
  
  ################################################################################
  ################################################################################
  #Plotting
  setwd(dir = paste0(resultdir))
  # pdf(paste0("Richness_CH_species_richness_current", ".pdf"), width = 10, height = 10)
  png(paste0("LATAM_Edible_food_","_species_richness_current", ".png"), width = 10, height = 10,
      units = "in",   # interpret as inches
      res = 1000)      # 300 dpi = print quality
  par(mfrow = c(1,1))
  par(mai = c(0.5, 0.5, 0.5, 0.5))
  plot(richness_total,
       main="",
       # main = paste0(region, " Species richness"),
       legend = T,
       col = viridis(length(species_list)))
  plot(sf::st_geometry(sf::st_as_sf(adm0)), add = TRUE, border = "grey17", lwd = 1.25)
  dev.off()
  
  
  ################################################################################
  message(paste("Step 5.9: HTML file step "))
  
  # Get the range of raster values (excluding NA)
  raster_values <- values(richness_total, na.rm = TRUE)
  richness_total_rl <- raster::raster(richness_total)  # convert to RasterLayer
  
  # num_classes <- 8  # Adjust this number as needed
  
  # Generate breaks using quantiles (0 to 90th percentile, then add max)
  breaks <-
    quantile(
      raster_values,
      probs = seq(0, 0.9, length.out = num_classes + 1),
      na.rm = TRUE
    )
  x_b <- quantile(raster_values, probs = 1, na.rm = TRUE)
  breaks <- c(breaks, x_b)
  breaks <- as.numeric(round(breaks, 0))
  breaks <- unique(breaks)
  
  actual_num_classes <- length(breaks) - 1
  colors <- turbo(actual_num_classes)
  
  # ?????? Automatic label generation ??
  # For each bin [breaks[i], breaks[i+1]):
  #   . single-value bin  ??? "N"
  #   . last bin          ??? ">N"  (open upper end)
  #   . all others        ??? "N-M"
  
  
  auto_labels <- sapply(seq_len(actual_num_classes), function(i) {
    lo <- breaks[i]
    hi <- breaks[i + 1]
    if (i == actual_num_classes) {
      # last class: open upper bound
      paste0(">", lo)
    } else if (lo == hi - 1 || lo == hi) {
      # single-value class
      as.character(lo)
    } else {
      paste0(lo, "-", hi - 1)              # closed range shown as lo - (hi-1)
    }
  })
  
  
  
  # Create categorical colour palette
  pal <- colorBin(
    palette   = colors,
    domain    = values(richness_total),
    bins      = breaks,
    na.color  = "transparent"
  )
  
  x <- leaflet() %>%
    addTiles() %>%
    addProviderTiles(providers$CartoDB.Positron) %>%
    addMiniMap(width = 150, height = 150) %>%
    addRasterImage(
      richness_total_rl,
      colors   = pal,
      opacity  = 0.3,
      project  = TRUE,
      maxBytes = 20 * 1024 ^ 2
    ) %>%
    addLegend(
      pal      = pal,
      values   = values(richness_total),
      title    = "Species Richness",
      labFormat = function(type, cuts, p)
        auto_labels  # fully automatic
    )

  htmlwidgets::saveWidget(
    x,
    paste0(
      resultdir,
      "/",
      "species_richness_total.html"
    ),
    selfcontained = F
  )
  message(paste("DONE: "))
  message(paste0("saved in ",resultdir))
  
  return("DONE!")
}

user <- "Chrystian"
if(user == "Chrystian") {
  basedir <-  "/catalogue/MultifLandscapesA1706"
}


species_selected <- as.data.frame(
  readxl::read_xlsx(
    "/catalogue/MultifLandscapesA1706/1.Data/Results/species_lists/Species_20250304_edible_part_curated.xlsx",
    col_names = T
  )
)

#template
#load template for rasterize
template <-
  rast(paste0(
    "/catalogue/MultifLandscapesA1706/1.Data/RAW/Input_data/climate_data/2_5min/present/",
    "wc2.1_2.5m_bio_1.tif"
  ))

template[which(!is.na(template[]))] <- 1

num_classes <- 8
summary_richness_function(basedir,resultdir,template,species_selected,num_classes)
