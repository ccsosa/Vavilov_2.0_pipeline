library(terra)
user <- "Chrystian"
# set base directory
if(user == "Chrystian") {
  basedir <- "E:/CSOSA/Dropbox/SDM D4R"
}

################################################################################
resultdir <- "E:/CSOSA/Dropbox/SDM D4R/SDM results/SA coffee/Maxent 4"
# set target region
region<- "SA coffee"
# set output directory
outputdir <- paste0(basedir, "/SDM results/", region, "/Maxent 4")

intersect_SBTN <- function(basedir,region,resultdir,outputdir){
################################################################################
coverage_intersect_dir <- paste0(resultdir,"/","coverage_intersect")
if(!dir.exists(coverage_intersect_dir)){
  dir.create(coverage_intersect_dir)
}


################################################################################
coverage <- rast(paste0(basedir,
                        "/Input data/Other spatial data/SBTN Natural Lands/",
                        "SBTN_Percentage_Converted_1km.tif"))
coverage_thr <- coverage
coverage_thr[which(coverage_thr[]<0.5)] <-NA
coverage_thr[which(coverage_thr[]>=.5)] <-1
rm(coverage);gc()
################################################################################
#gettting speies lists to get results
metrics <- read.csv(paste0(resultdir,"/","AUC_Maxent.csv"))

species_list <- metrics$species
species_list <- sub(pattern = "model_evaluation_",replacement = "",species_list)
species_list <- sub(pattern = ".csv",replacement = "",species_list)

################################################################################
#adding presence absence results folder
InDir <- paste0(resultdir,"/Distribution maps/Presence-absence")

#calling SDM results
####First step (summary file)
message("Reading all rasters from species list")
#reading raster
files_to <- lapply(1:length(species_list),function(i){
  x <- terra::rast(paste0(InDir,"/",species_list[[i]],".tif"))
  x[which(x[]==0)] <- NA
  return(x)
})
gc()
#resampling to get coverage with equal cells as SDMs
coverage_thr <- terra::resample(coverage_thr,files_to[[1]],method="near")
gc()
################################################################################
#obtaining intersection as SDM * 50% > coverage conversion (Only intersection of 1)
files_to_cov <- lapply(1:length(species_list),function(i){
  x <- files_to[[i]]* coverage_thr
  x[which(x[]==0)] <- NA
  x2_sdm <- terra::expanse(files_to[[i]],unit="km")
  x2 <- terra::expanse(x,unit="km")
  terra::writeRaster(x,
                     filename = paste0(coverage_intersect_dir,"/",species_list[[i]],
                                       "_SBTN_intersected.tif"),
                     overwrite=T)
  x2 <- data.frame(species = species_list[[i]],
                   total_area = x2_sdm$area,
                   forest_area = x2$area,
                   ratio = x2$area/x2_sdm$area)
  return(x2)
})
gc()
coverage_spList <- do.call(rbind,files_to_cov)
write.csv(coverage_spList, paste0(resultdir,"/","coverage_SBTN_table", ".csv"))

}

intersect_SBTN(basedir,region,resultdir,outputdir)
