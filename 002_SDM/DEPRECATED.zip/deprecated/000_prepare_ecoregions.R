require(terra)
require(sf)

#base dir
basedir <- "E:/CSOSA/Dropbox/VAVILOV_2.0/DATA"

ecoregions <- terra::vect(paste0(basedir,"/Ecoregions/","Ecoregions2017.shp"))

#templates
template <- terra::rast(paste0(basedir,"/Input_data/climate_data/30s/present/wc2.1_30s_bio_1.tif"))
template_2_5min <- terra::rast(paste0(basedir,"/Input_data/climate_data/2_5min/present/wc2.1_2.5m_bio_1.tif"))

#rasterize
eco_raster <- terra::rasterize(x=ecoregions,y=template,field="ECO_ID")
#save
writeRaster(eco_raster,paste0(basedir,"/","Input_data/Other spatial data/30s/","ecoregiones.tif"))
#resample to 2.5 min
eco_raster_2_5 <- terra::resample(x = eco_raster,y=template_2_5min,method="near")
#saving
writeRaster(eco_raster_2_5,paste0(basedir,"/","Input_data/Other spatial data/2_5min/","ecoregiones.tif"))
