### this script can be used to put the AUC values and thresholds of the 
# calibrated models in a single table

# author: Tobias Fremout (tobias.fremout@gmail.com)

# set directory where the results of the modelling are stored # ADAPT FOLDER IF NECESSARY
resultdir <- "/catalogue/MultifLandscapesA1706/1.Data/Results/CWR_results"

# load evaluation data 
setwd(dir = paste0(resultdir, "/Model evaluation"))
files <- list.files()
files_list <- list()
for (i in 1:length(files)) {
  x <- read.csv(files[i])
  
  if(nrow(x)==0){
    message(paste0("check ", files[[i]]))
    # print(i)
    # x[1,] <- NA
    # x$sensitivity <- NA
    # x$specificity <- NA
    # x$TSS <- NA
    # x$OPR <- NA
    # x$UPR <- NA
  } else {
    x$species <- files[[i]]
  }

  files_list[[i]] <- x
  
}
AUC_table <- do.call(rbind, files_list)
# AUC_table$species <- files

# save
setwd(dir = resultdir)
write.csv(AUC_table, "AUC_Maxent.csv")

# load thresholds
setwd(dir = paste0(resultdir, "/Model thresholds"))
files <- list.files()
files_list <- list()
for (i in 1:length(files)) {
  files_list[[i]] <- read.csv(files[i])
}
thr_table <- do.call(rbind, files_list)
thr_table$species <- files

# save
setwd(dir = resultdir)
write.csv(thr_table, "thresholds_Maxent.csv")


AUC_table_valid <- AUC_table[which(AUC_table$auc.val.avg>=0.7),]
# save
setwd(dir = resultdir)
write.csv(AUC_table_valid, "AUC_Maxent_valid.csv")





