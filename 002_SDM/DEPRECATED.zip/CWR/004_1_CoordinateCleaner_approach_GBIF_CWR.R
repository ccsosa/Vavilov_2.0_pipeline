# Load necessary libraries
require(CoordinateCleaner)  # For automated cleaning of geographic coordinates in species occurrence data
require(readxl)             # For reading Excel files (not used in this code but loaded)
require(data.table)         # For efficient data manipulation and fast file reading

# Function to clean species occurrence coordinates using CoordinateCleaner
clean_coordinates <- function(x, basedir, cleanDir) {
  # Apply coordinate cleaning tests to flag problematic records
  # Tests include:
  # - capitals: flags points near country capitals (within 5000m)
  # - centroids: flags points near country centroids (within 5000m)
  # - equal: flags points with equal lat/lon coordinates
  # - gbif: flags points outside country borders according to GBIF
  # - institutions: flags points near biodiversity institutions (within 5000m)
  # - outliers: flags geographic outliers within species occurrence points
  # - seas: flags points located in the sea
  # - zeros: flags points with zero coordinates
  flags <- CoordinateCleaner::clean_coordinates(
    x = x,
    lon = "lon",
    lat = "lat",
    countries = NULL,
    capitals_rad = 5000,
    inst_rad = 5000,
    centroids_rad = 5000,
    species = "species",
    tests = c(
      "capitals",
      "centroids",
      "equal",
      "gbif",
      "institutions",
      "outliers",
      "seas",
      "zeros"
    )
  )
  
  # Subset data to exclude flagged problematic records
  dat_cl <- x[flags$.summary, ]   # Good records
  dat_fl <- x[!flags$.summary, ]  # Flagged problem records (not returned but could be saved if needed)
  
  # Return cleaned dataset with flagged records removed
  return(dat_cl)
}

# Define directories for working and cleaned data storage
basedir <- "//catalogue/MultifLandscapesA1706"
cleanDir <- "//catalogue/MultifLandscapesA1706/1.Data/Results/CWR_results/occurrences/cleaned"

# Load GBIF cleaned data for first round and apply coordinate cleaning function
x <- read.csv(paste0(cleanDir, "/", "GBIF_data_CWR_cleaned.csv"))
x_names <- colnames(x)
x <- x[,-c(14,15)]
colnames(x) <- c(
"species",
"species_searched",
"country",
"year",
"adm1",
"locality",
"collection_code",
"dataset_name",
"dataset_key",
"institution_code",
"source",
"GID_0",
"NAME_0",
"lon",
"lat"
)

dat_cl <- clean_coordinates(x, basedir, cleanDir)
write.csv(dat_cl, paste0(cleanDir, "/", "GBIF_data_cleaned_FINAL.csv"))

# Load GBIF cleaned data for second round and apply coordinate cleaning function
# x <- fread(paste0(cleanDir, "/", "GBIF_data_CWR_year_cleaned.csv"))
# dat_cl <- clean_coordinates(x, basedir, cleanDir)
# write.csv(dat_cl, paste0(cleanDir, "/", "GBIF_data_second_round_cleaned_FINAL.csv"))

# Uncomment below to rename columns or run external scripts if needed
# colnames(dat_cl)[1:3]<- c("scientific_name","latitude","longitude")
# write.csv(dat_cl,"D:/BOLDER/bactris_gasipaes/occurences.csv")

# x1 <- fread(paste0(cleanDir, "/", "GBIF_data_cleaned_FINAL.csv"))
# x2 <- fread(paste0(cleanDir, "/", "GBIF_data_second_round_cleaned_FINAL.csv"))
# 
# x3 <- rbind(x1,x2)
# write.csv(x3, paste0(cleanDir, "/", "GBIF_joined_FINAL.csv"))


################################################################################
#removing problematic coord from Field Museum -65.9119 - 7.0758
# require(data.table)
# occs <- fread("E:/CSOSA/Dropbox/VAVILOV_2.0/DATA/DATABASES/occurrences/cleaned/GBIF_joined_FINAL.csv",
#               header = T)

# occs <- occs[, -c(1, 2,3,4,5)]
# #fixing column names
# colnames(occs) <- c(
#   "species",
#   "species_searched",
#   "country",
#   "year",
#   "adm1",
#   "locality",
#   "collection_code",
#   "dataset_name",
#   "dataset_key",
#   "institution_code",
#   "source",
#   "GID_0",
#   "NAME_0",
#   "geometry_long",
#   "geometry_lat",
#   "lon",
#   "lat"
# )
# 

# if(file.exists(paste0(cleanDir, "/", "GBIF_joined_FINAL_2.csv"))){
  # occs <- fread(paste0(cleanDir, "/", "GBIF_joined_FINAL_2.csv"),
  #               header = T)
  # occs <- dat_cl
  # occs$coords <- paste(occs$lon,"-",occs$lat)
  # x <- tapply(occs$coords,occs$coords,length)
  # x <- x[order(x,decreasing=T)]
  #visualizing
  # occs2 <- occs
  # occs2 <- occs2[which(occs2$coords==names(x)[1]),]
  
  #subsetting
  # occs3 <- occs[which(occs$coords!="-65.9119 - 7.0758"),]
  # write.csv(occs3, paste0(cleanDir, "/", "GBIF_joined_FINAL_2.csv"))
  # 
# # } else  {
#   occs <- fread(paste0(cleanDir, "/", "GBIF_joined_FINAL_2.csv"),
#                 header = T)
  # occs$V1 <- NULL
  # x <- tapply(occs$coords,occs$coords,length)
  # x <- x[order(x,decreasing=T)]
  # x2 <- x[x>200]
  # occs3 <- occs[!occs$coords %in% names(x2),]
  # write.csv(occs3, paste0(cleanDir, "/", "GBIF_joined_FINAL_3.csv"))
# }

