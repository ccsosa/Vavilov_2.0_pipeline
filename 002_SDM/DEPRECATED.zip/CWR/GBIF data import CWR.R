### This script imports GBIF occurrence records for a set of species

# author: Tobias Fremout (tobias.fremout@gmail.com)

# load packages
library(dismo)
library(terra)
library(parallel)
library(pbapply)

# set base directory
basedir <- "/catalogue/MultifLandscapesA1706/1.Data/Results"
CWR_dir <- paste0(basedir,"/","CWR_results")
if(!dir.exists(CWR_dir)){
  dir.create(CWR_dir)
}

org_dir <- paste0(CWR_dir,"/","occurrences")
if(!dir.exists(org_dir)){
  dir.create(org_dir)
}
# set target region

# load species sets to download data
species_set <- readxl::read_xlsx("/catalogue/MultifLandscapesA1706/1.Data/RAW/CWR/CWR_LATAM_list.xlsx")

# get only the species names
species_set <- species_set$species
# head(species_set)
# length(species_set)


#GBIF_Download <- function(basedir,region,species_set){

# if(!file.exists(paste0(basedir, 
#                       "/Input data/Occurrence records/", 
#                       region, 
#                       "/Original",
#                       "/",
#                       "GBIF_data_download_",
#                       region,
#                       ".csv"))){ 
# make dataframe with genus and spec. epithets

species_set <- data.frame(species = species_set,
                          genus = NA,
                          specEpithet = NA)
for (i in 1:nrow(species_set)) {
  species_split <- strsplit(species_set$species[i], " ")[[1]]
  species_set$genus[i] <- species_split[1]
  species_set$specEpithet[i] <- species_split[2]
};rm(i)

#head(species_set)

# load raster of modelling region
t <- raster("/catalogue/MultifLandscapesA1706/1.Data/RAW/Input_data/climate_data/30s/present/wc2.1_30s_bio_1.tif")
#check raster
#plot(t)

# get extent of this raster
ex <- extent(t)
#remove raster  
rm(t)
#ex

# make an empty list to store the downloaded data in
#occGBIF <- list()

# Adding six cores to download info
numCores <- 32

gbif_parallel_function <- function(species_set,ex,numCores){
#adding this to allow parallel working for R>=3.6
rscript_args = c("-e", shQuote("getRversion"))
#preparing n cores 
cl <- parallel::makeCluster(numCores)
#exporting files to each of the n cores used 
parallel::clusterExport(cl, varlist=c("species_set",
                                      "ex"),envir=environment())

# download the GBIF data with a for-loop (n loops (numCores) at time!)
occGBIF <- parallel::parLapplyLB(
#occGBIF <- pbapply::pblapply(
                                cl=cl,
                                #X = seq_along((species_set$species)),
                                X = seq_len(length(species_set$species)),
                                    fun = function (i){                                 
                                    #FUN = function (i){


# download the GBIF data with a for-loop
#for (i in 1:length(species_set$species)) {

  # keep track of loop
  cat(paste0("species number ", i, ": ", species_set$species[i], sep=""))
  # download GBIF data (t_1 to avoid overlap with transpose function in R!)
  t_1 <- try(
    GBIF <- dismo::gbif(
      genus = as.character(species_set$genus[i]),
      species = as.character(species_set$specEpithet[i]),
      ext = ex,
      geo = TRUE,
      removeZeros = TRUE,
      download = TRUE,
      ntries = 300 #new number is 300 (There are issues with 100. Some species are ommited)
    ))
  
  if (class(t_1) == "try-error") {
    GBIF <- NULL
  }
  
  #System sleep for three seconds
  Sys.sleep(time = 3)
  # organize the downloaded data
  
  if (!is.null(GBIF)) {   
    
    # delete duplicates
    j <- which(duplicated(GBIF$lat, GBIF$lon))
    if(length(j) > 0) {
      GBIF <- GBIF[-j,]
    }

    # add an extra variable with the species name that was searched for (not using the GBIF taxonomy)
    GBIF$species_searched <- rep(species_set$species[i], nrow(GBIF))
    
    # get the relevant variables
    species <- GBIF$acceptedScientificName
    species_searched <- GBIF$species_searched
    lon <- GBIF$lon
    lat <- GBIF$lat
    country <- GBIF$country
    
    # the following variables may be missing so select only if available
    j <- which(names(GBIF) == "year")
    if (length(j) > 0) {
      year <- GBIF$year
    } else {
      year <- rep(NA, nrow(GBIF))
    }
    j <- which(names(GBIF) == "country")
    if (length(j) > 0) {
      country_name <- GBIF$country
    } else {
      country_name <- rep(NA, nrow(GBIF))
    }
    j <- which(names(GBIF) == "adm1")
    if (length(j) > 0) {
      adm1 <- GBIF$adm1
    } else {
      adm1 <- rep(NA, nrow(GBIF))
    }
    j <- which(names(GBIF) == "locality")
    if (length(j) > 0) {
      locality <- GBIF$locality
    } else {
      locality <- rep(NA, nrow(GBIF))
    }
    j <- which(names(GBIF) == "collectionCode")
    if (length(j) > 0) { 
      collection_code <- GBIF$collectionCode
      } else {
      collection_code <- rep(NA, nrow(GBIF))
    }
    j <- which(names(GBIF) == "datasetName")
    if (length(j) > 0) {
      dataset_name <- GBIF$datasetName
    } else {
      dataset_name <- rep(NA, nrow(GBIF))
    }
    j <- which(names(GBIF) == "datasetKey")
    if (length(j) > 0) {
      dataset_key <- GBIF$datasetKey
    } else {
      dataset_key <- rep(NA, nrow(GBIF))
    }
    j <- which(names(GBIF) == "institutionCode")
    if (length(j) > 0) {
      institution_code <- GBIF$institutionCode
    } else {
      institution_code <- rep(NA, nrow(GBIF))
    }
    
    GBIF <- data.frame(species = species,
                       species_searched = species_searched,
                       lon = as.numeric(as.character(lon)), 
                       lat = as.numeric(as.character(lat)), 
                       country = as.character(country_name), 
                       year = as.numeric(as.character(year)), 
                       adm1 = as.character(adm1), 
                       locality = as.character(locality),
                       collection_code = as.character(collection_code),
                       dataset_name = as.character(dataset_name),
                       dataset_key = as.character(dataset_key),
                       institution_code = as.character(institution_code),
                       source = "GBIF")
    
    # put in the list
    #occGBIF[[i]] <- GBIF
    
  }
  
})
parallel::stopCluster(cl)
# rbind the list
occGBIF_rbind <- do.call(rbind, occGBIF)
return(occGBIF_rbind)
}

rscript_args = c("-e", shQuote("getRversion()"))

occGBIF_rbind <- gbif_parallel_function(species_set,ex,numCores)
#dim(occGBIF_rbind)
# } else {
#   print("results available!")
# }
# # return(c(occGBIF_rbind))
#}
# save
setwd(dir = org_dir)
write.csv(occGBIF_rbind, paste0("GBIF_data_download_1", ".csv"))
# 
# #Checking species without GBIF recors to retry!
# sum(!species_set$species %in% unique(occGBIF_rbind$species_searched))
# #species without records (check)
# #i in the list to retry
# sp_n <- 1:length(species_set$species)
# #missing species
# sp_n <- sp_n[!species_set$species %in% unique(occGBIF_rbind$species_searched)]
# 
# 
# rscript_args = c("-e", shQuote("getRversion()"))
# missing_sp <- species_set[sp_n,]
# occGBIF_rbind2 <- gbif_parallel_function(missing_sp,ex,numCores)
