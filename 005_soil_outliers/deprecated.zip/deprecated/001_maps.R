require(readxl)
require(data.table)
require(dplyr)
require(ggplot2)
require(ggpubr)
require(terra)
require(foreach)
require(tidyterra)
require(dplyr)


summmary_raster_quantile <-
  function(basedir,
           resultdir,
           output_dir,
           species_selected,
           template_file,
           data_ori) {
    out_dir <- output_dir
    #richness
    out_buffer_dir <- paste0(out_dir, "/soil_extreme")
    if (!dir.exists(out_buffer_dir)) {
      dir.create(out_buffer_dir)
    }
    #species_raster_dir
    out_buffer_dir_raster <- paste0(out_buffer_dir, "/raster")
    if (!dir.exists(out_buffer_dir_raster)) {
      dir.create(out_buffer_dir_raster)
    }
    #summary_dir
    out_buffer_dir_summary <- paste0(out_buffer_dir, "/summary2")
    if (!dir.exists(out_buffer_dir_summary)) {
      dir.create(out_buffer_dir_summary)
    }
    #folder for PNG, TIF, and HTML files
    out_buffer_dir_summary_png <-
      paste0(out_buffer_dir_summary, "/", "PNG")
    out_buffer_dir_summary_tif <-
      paste0(out_buffer_dir_summary, "/", "TIF")
    out_buffer_dir_summary_html <-
      paste0(out_buffer_dir_summary, "/", "HTML")
    
    
    message(out_buffer_dir_summary)
    
    
    if (!dir.exists(out_buffer_dir_summary_png)) {
      dir.create(out_buffer_dir_summary_png)
    }
    if (!dir.exists(out_buffer_dir_summary_tif)) {
      dir.create(out_buffer_dir_summary_tif)
    }
    if (!dir.exists(out_buffer_dir_summary_html)) {
      dir.create(out_buffer_dir_summary_html)
    }
    
    # chunks summary_dir
    out_buffer_dir_summary_chunks <-
      paste0(out_buffer_dir_summary, "/chunks")
    if (!dir.exists(out_buffer_dir_summary_chunks)) {
      dir.create(out_buffer_dir_summary_chunks)
    }
    ################################################################################
    
data <- data_ori[which(data_ori$prop_eco_total >= 20), ]

variables <- unique(data$var)
################################################################################
# species_selected <- read.csv(
#   paste0(out_buffer_dir_summary, "/", "species_selected.csv")
# )
#categories to perform analyses

################################################################################
template <- terra::rast(template_file)
template[which(!is.na(template[]))] <- 1
###########################################
##############################################################################
#loading adm0
message("loading shapefile and metrics")
adm0 <-
  vect(paste0(basedir, "/1.Data/RAW/input_data/adm0/adm0_Latam", ".shp"))

# ecco <- vect(paste0(basedir, "/1.Data/RAW/input_data/Ecoregions/Ecoregions2017", ".shp"))
# # --- Ecosystems layer (SpatVector → sf) ---
# ecco_sf <- sf::st_as_sf(ecco)
# # Fix invalid geometries
# ecco_sf <- sf::st_make_valid(ecco_sf)

# ecco_sf_BIOM <- aggregate(
#   x = ecco_sf[, "geometry"],
#   by = list(BIOME = ecco_sf$BIOME_NAME),
#   FUN = sum,
#   do_union = TRUE
# )
# write_sf(ecco_sf_BIOM,"/catalogue/MultifLandscapesA1706/1.Data/RAW/Input_data/Ecoregions/biomes_2017.shp")
#
# ecco <- vect(paste0(basedir, "/1.Data/RAW/input_data/Ecoregions/biomes_2017.shp"))
# ecco_sf <- sf::st_as_sf(ecco)
# # Fix invalid geometries
# ecco_sf <- sf::st_make_valid(ecco_sf)
# sf::sf_use_s2(FALSE)
# ecco_sf <- sf::st_transform(ecco_sf, crs = terra::crs(template))
# latam_bbox <- sf::st_as_sfc(sf::st_bbox(terra::ext(template)[c(1,3,2,4)]))
# sf::st_crs(latam_bbox) <- terra::crs(template)
# # Clip ecco_sf to raster extent
# ecco_sf_latam <- sf::st_intersection(ecco_sf, latam_bbox)
# write_sf(ecco_sf_latam,"/catalogue/MultifLandscapesA1706/1.Data/RAW/Input_data/Ecoregions/biomes_LATAM_2017.shp")
ecco <-
  sf::read_sf(paste0(
    basedir,
    "/1.Data/RAW/input_data/Ecoregions/biomes_LATAM_2017.shp"
  ))
sf::sf_use_s2(FALSE)
# ecco <- sf::st_make_valid(sf::st_as_sf(ecco))

#all species
species_total <- unique(species_selected$species)
##############################################################################
#loading buffer species
InDir_buffer <-
  "/catalogue/MultifLandscapesA1706/1.Data/Results/buffer_richness/raster"
#species with buffer
sp_buffer_list <- list.files(InDir_buffer, pattern = ".tif")
sp_buffer_list_name <-
  sub(pattern = ".tif", replacement = "", sp_buffer_list)
##############################################################################
#load metrics to get modeled species
metrics <-
  read.csv(paste0(resultdir, "/", "AUC_Maxent_valid.csv"))
#gettting species lists to get results (modeled species with MaxEnt)
species_list <- metrics$species
species_list <-
  sub(pattern = "model_evaluation_", replacement = "", species_list)
species_list <-
  sub(pattern = ".csv", replacement = "", species_list)
# print(length(species_list))
# species_list <- species_list[which(species_list!="Cabralea canjerana")]
# print(length(species_list))
#species with valid model
avail_sp_modeled <-
  species_list[species_list %in% species_total]
##############################################################################
#species with buffer
# buffer_sps <- species_total[sp_buffer_list_name %in% species_total]
buffer_sps <-
  species_total[!species_total %in% avail_sp_modeled]
#if buffer_sps + avail_sp_modeled =8221 is well done!
buffer_sps <-
  buffer_sps[buffer_sps %in% sp_buffer_list_name] #available to use buffer
##############################################################################
#adding presence absence results folder
InDir <-
  paste0(resultdir, "/Distribution maps/Presence-absence")
################################################################################
#getting species Q10 amd Q90

quantiles <- c("Q10", "Q90")

for (i in 1:length(variables)) {
  # i <- 1
  variable <- variables[[i]]
  # j <- 1
  for (j in 1:2) {
    quant <- quantiles[[j]]
    
    data_var_i <- data[which(data$var == variable), ]
    data_var_i_Quantile <-
      data_var_i$species_searched[which(data_var_i[, quant] == TRUE)]
    
    ################################################################################
    avail_sp_modeled_i <-
      data_var_i_Quantile[data_var_i_Quantile %in% avail_sp_modeled]
    buffer_sps_i <-
      data_var_i_Quantile[data_var_i_Quantile %in% buffer_sps]
    
    ################################################################################
    
    #message("Doing summary for current (parallel chunked mode)")
    if (!file.exists(
      paste0(
        out_buffer_dir_summary_tif,
        "/",
        variable,
        "_",
        quant,
        "_",
        "SDM_richness_current.tif"
      )
    )) {
      # --- 1. Validate paths sequentially ---------------------------------------
      message("Checking file availability...")
      valid_paths <-
        vapply(avail_sp_modeled_i, function(sp) {
          path <- paste0(InDir, "/", sp, ".tif")
          if (file.exists(path))
            path
          else
            NA_character_
        }, character(1))
      
      missing_sps <-
        avail_sp_modeled_i[is.na(valid_paths)]
      valid_paths <- valid_paths[!is.na(valid_paths)]
      
      if (length(missing_sps) > 0)
        message(paste0(
          length(missing_sps),
          " species raster(s) not found and skipped."
        ))
      message(paste0(length(valid_paths), " valid rasters found."))
      # --- 2. Split into chunks of 100 ------------------------------------------
      if (length(valid_paths) < 10) {
        chunk_size <- length(valid_paths)
      } else {
        chunk_size <- 10
      }
      chunk_idx  <- split(seq_along(valid_paths),
                          ceiling(seq_along(valid_paths) / chunk_size))
      n_chunks   <- length(chunk_idx)
      message(paste0(
        "Processing ",
        n_chunks,
        " chunks of up to ",
        chunk_size,
        " rasters..."
      ))
      
      # --- 3. Setup parallel backend --------------------------------------------
      n_cores <- 8 #min(parallel::detectCores() - 2, n_chunks)
      cl      <- parallel::makeCluster(n_cores)
      doParallel::registerDoParallel(cl)
      message(paste0("Using ", n_cores, " cores for ", n_chunks, " chunks"))
      
      # --- Create chunks subfolder ----------------------------------------------
      chunk_dir <-
        paste0(out_buffer_dir_summary_chunks, "/chunks2")
      if (!dir.exists(chunk_dir))
        dir.create(chunk_dir)
      
      # --- 4. Parallel chunk summation with NA → 0 ------------------------------
      chunk_results <- foreach::foreach(
        chunk          = chunk_idx,
        .packages      = "terra",
        .errorhandling = "pass"
      ) %dopar% {
        paths_chunk <- valid_paths[chunk]
        chunk_id    <-
          chunk[1]  # use first index as unique chunk identifier
        
        stack  <- terra::rast(paths_chunk)
        result <- terra::app(stack, fun = "sum", na.rm = TRUE)
        
        # Save to known folder with predictable name
        out_path <-
          paste0(chunk_dir,
                 "/chunk_",
                 sprintf("%04d", chunk_id),
                 ".tif")
        terra::writeRaster(result,
                           filename = out_path,
                           overwrite = TRUE)
        out_path
      }
      
      parallel::stopCluster(cl)
      
      # --- 5. Check for chunk errors --------------------------------------------
      failed <- sapply(chunk_results, inherits, "error")
      if (any(failed)) {
        message(paste0(sum(failed), " chunk(s) failed:"))
        print(chunk_results[failed])
        stop("Aborting: fix failed chunks before proceeding.")
      }
      
      # --- 6. Final sum across chunk files --------------------------------------
      message("Combining chunk results into final richness raster...")
      chunk_paths <- unlist(chunk_results)
      chunk_stack <- terra::rast(chunk_paths)
      x           <-
        terra::app(chunk_stack, fun = "sum", na.rm = TRUE)
      
      # --- 7. Save final raster -------------------------------------------------
      message("Saving species_richness_current.tif ...")
      terra::writeRaster(
        x,
        filename  = paste0(
          out_buffer_dir_summary_tif,
          "/",
          variable,
          "_",
          quant,
          "_",
          "SDM_richness_current.tif"
        ),
        overwrite = TRUE
      )
      
      # --- 8. Cleanup chunks folder ---------------------------------------------
      message("Cleaning up chunk files...")
      file.remove(chunk_paths)
      unlink(chunk_dir)
      richness <- x
      message("Done!")
    } else {
      richness <- terra::rast(
        paste0(
          out_buffer_dir_summary_tif,
          "/",
          variable,
          "_",
          quant,
          "_",
          "SDM_richness_current.tif"
        )
      )
      
    }
    
    
    ################################################################################
    ################################################################################
    #creating for buffer
    message("Doing for buffer")
    if (!file.exists(
      paste0(
        out_buffer_dir_summary_tif,
        "/",
        variable,
        "_",
        quant,
        "_",
        "buffer_richness_current.tif"
      )
    )) {
      message("Doing summary for current (parallel chunked mode)")
      
      # --- 1. Validate paths sequentially ---------------------------------------
      message("Checking file availability...")
      valid_paths <- vapply(buffer_sps_i, function(sp) {
        path <- paste0(InDir_buffer, "/", sp, ".tif")
        if (file.exists(path))
          path
        else
          NA_character_
      }, character(1))
      
      missing_sps <- buffer_sps_i[is.na(valid_paths)]
      valid_paths <- valid_paths[!is.na(valid_paths)]
      
      if (length(missing_sps) > 0)
        message(paste0(
          length(missing_sps),
          " species raster(s) not found and skipped."
        ))
      message(paste0(length(valid_paths), " valid rasters found."))
      
      # --- 2. Split into chunks of 100 ------------------------------------------
      
      if (length(valid_paths) < 10) {
        chunk_size <- length(valid_paths)
      } else {
        chunk_size <- 10
      }
      
      chunk_idx  <- split(seq_along(valid_paths),
                          ceiling(seq_along(valid_paths) / chunk_size))
      n_chunks   <- length(chunk_idx)
      message(paste0(
        "Processing ",
        n_chunks,
        " chunks of up to ",
        chunk_size,
        " rasters..."
      ))
      
      # --- 3. Setup parallel backend --------------------------------------------
      n_cores <- 8 #min(parallel::detectCores() - 2, n_chunks)
      cl      <- parallel::makeCluster(n_cores)
      doParallel::registerDoParallel(cl)
      message(paste0("Using ", n_cores, " cores for ", n_chunks, " chunks"))
      
      # --- Create chunks subfolder ----------------------------------------------
      chunk_dir <-
        paste0(out_buffer_dir_summary_tif, "/chunks2")
      if (!dir.exists(chunk_dir))
        dir.create(chunk_dir)
      
      # --- 4. Parallel chunk summation with NA → 0 ------------------------------
      chunk_results <- foreach::foreach(
        chunk          = chunk_idx,
        .packages      = "terra",
        .errorhandling = "pass"
      ) %dopar% {
        paths_chunk <- valid_paths[chunk]
        chunk_id    <-
          chunk[1]  # use first index as unique chunk identifier
        
        stack  <- terra::rast(paths_chunk)
        result <- terra::app(stack, fun = "sum", na.rm = TRUE)
        
        # Save to known folder with predictable name
        out_path <-
          paste0(chunk_dir,
                 "/chunk_",
                 sprintf("%04d", chunk_id),
                 ".tif")
        terra::writeRaster(result,
                           filename = out_path,
                           overwrite = TRUE)
        out_path
      }
      
      parallel::stopCluster(cl)
      
      # --- 5. Check for chunk errors --------------------------------------------
      failed <- sapply(chunk_results, inherits, "error")
      if (any(failed)) {
        message(paste0(sum(failed), " chunk(s) failed:"))
        print(chunk_results[failed])
        stop("Aborting: fix failed chunks before proceeding.")
      }
      
      # --- 6. Final sum across chunk files --------------------------------------
      message("Combining chunk results into final richness raster...")
      chunk_paths <- unlist(chunk_results)
      chunk_stack <- terra::rast(chunk_paths)
      x           <-
        terra::app(chunk_stack, fun = "sum", na.rm = TRUE)
      
      # --- 7. Save final raster -------------------------------------------------
      message("Saving species_richness_buffer_current.tif ...")
      terra::writeRaster(
        x,
        filename  = paste0(
          out_buffer_dir_summary_tif,
          "/",
          variable,
          "_",
          quant,
          "_",
          "buffer_richness_current.tif"
        ),
        overwrite = TRUE
      )
      richness_buffer <- x
      # --- 8. Cleanup chunks folder ---------------------------------------------
      message("Cleaning up chunk files...")
      file.remove(chunk_paths)
      unlink(chunk_dir)
      message("Done!")
      
    } else {
      richness_buffer <-
        terra::rast(
          paste0(
            out_buffer_dir_summary_tif,
            "/",
            variable,
            "_",
            quant,
            "_",
            "buffer_richness_current.tif"
          )
        )
      
    }
    ####
    
    richness_res <-
      richness #terra::resample(richness,template,method="near")
    if (!is.null(richness_res) & !is.null(richness_buffer)) {
      message("SDM AVAIL, BUFFER AVAIL")
      
      richness_buffer_res <-
        terra::resample(richness_buffer, template, method = "near")
      richness_total <- sum(richness_res, richness_buffer_res, na.rm = T)
      
      terra::writeRaster(
        richness_total,
        filename  = paste0(
          out_buffer_dir_summary_tif,
          "/",
          variable,
          "_",
          quant,
          "_",
          "richness_current.tif"
        ),
        overwrite = TRUE
      )
      
      
    } else if (is.null(richness_res) &
               !is.null(richness_buffer)) {
      message("SDM AVAIL, BUFFER AVAIL")
      
      richness_buffer_res <-
        terra::resample(richness_buffer, template, method = "near")
      richness_total <- richness_buffer_res
      
      terra::writeRaster(
        richness_total,
        filename  = paste0(
          out_buffer_dir_summary_tif,
          "/",
          variable,
          "_",
          quant,
          "_",
          "richness_current.tif"
        ),
        overwrite = TRUE
      )
      
    } else if (!is.null(richness_res) &
               is.null(richness_buffer)) {
      message("NO SDM, BUFFER AVAIL")
      richness_total <- richness_res
      
      terra::writeRaster(
        richness_total,
        filename  = paste0(
          out_buffer_dir_summary_tif,
          "/",
          variable,
          "_",
          quant,
          "_",
          "richness_current.tif"
        ),
        overwrite = TRUE
      )
      
    } else if (is.null(richness_res) &
               is.null(richness_buffer)) {
      message("NO FILE TO MAP")
      richness_total <- NULL
      
    }
    richness_total[which(richness_total[] == 0)] <- NA
    
    
    ################################################################################
    message("Making a plot")
    
    # # Plotting
    # setwd(out_buffer_dir_summary_png)
    # # png(
    # #   paste0(
    # #     "LATAM_Edible_food_",
    # #     variable,
    # #     "_",
    # #     "Q10",
    # #     "_species_richness_current",
    # #     ".png"
    # #   ),
    # #   width = 10,
    # #   height = 10,
    # #   units = "in",
    # #   # interpret as inches
    # #   res = 1000
    # # )      # 300 dpi = print quality
    # #
    # #
    # # plot(
    # #   richness_total,
    # #   main = "",
    # #   #main = paste0("Species richness"),
    # #   legend = T,
    # #   col = viridis(length(species_list))
    # # )
    # #
    # # plot(
    # #   sf::st_geometry(ecco ),
    # #   add    = T,
    # #   border = "white",
    #   col    = NA,
    #   lwd    = 0.8,
    #   lty    = 2
    # )
    #
    # # Ecosystem labels
    # ecosystem_centroids <- sf::st_point_on_surface(ecco )
    # ecosystem_coords    <- sf::st_coordinates(ecosystem_centroids)
    #
    # text(
    #   x      = ecosystem_coords[, 1],
    #   y      = ecosystem_coords[, 2],
    #   labels = ecco $BIOME,
    #   cex    = 0.5,        # small enough to fit
    #   col    = "white",
    #   font   = 2
    # )
    #
    # # --- Country borders ---
    # plot(
    #   sf::st_geometry(sf::st_as_sf(adm0)),
    #   add    = TRUE,
    #   border = "grey17",
    #   lwd    = 1.25
    # )
    #
    # dev.off()
    
    
    # Get centroid coordinates as dataframe
    biome_centroids <- sf::st_point_on_surface(ecco)
    biome_coords_df <- data.frame(sf::st_coordinates(biome_centroids),
                                  BIOME_NAME = ecco$BIOME)
    
    # Remove NA biomes
    biome_coords_df <-
      biome_coords_df[!is.na(biome_coords_df$BIOME_NAME) &
                        biome_coords_df$BIOME_NAME != "N/A",]
    
    p <- ggplot() +
      # scale_fill_gradient2(
      #   low      = "blue",
      #   mid      = "yellow",
      #   high     = "red",
      #   midpoint = 60,
      #   na.value = NA,
      #   name     = "Species\nRichness"
      # ) +
      scale_fill_gradientn(
        colours  = rev(RColorBrewer::brewer.pal(11, "Spectral")),
        na.value = NA,
        name     = "Species\nRichness"
      ) +


      tidyterra::geom_spatraster(data = richness_total,
                                 na.rm = T) +
      
      
      geom_sf(
        data = sf::st_as_sf(adm0),
        fill = NA,
        color = "grey17",
        linewidth = 1.2
      ) +
      geom_sf(
        data = ecco,
        fill = NA,
        color = "white",
        linewidth = 0.4,
        linetype = 1
      ) +
      ggrepel::geom_label_repel(
        data             = biome_coords_df,
        aes(x = X, y = Y, label = BIOME_NAME),
        color            = "black",
        na.rm            = T,
        fill             = "gray86",
        size             = 2.1,
        fontface         = "bold",
        box.padding      = 0.5,
        point.padding    = 0.3,
        max.iter         = 50000,
        max.overlaps     = Inf,
        force            = 100,
        force_pull       = 1,
        nudge_x          = ifelse(biome_coords_df$X < -75,-25, 20),
        # push left or right outside map
        nudge_y          = ifelse(biome_coords_df$Y > 10, 15,-15),
        # push up or down outside map
        arrow            = arrow(
          length = unit(0.015, "npc"),
          type = "closed",
          ends = "last"
        ),
        segment.color    = "grey30",
        segment.size     = 0.4,
        segment.curvature = 0.2,
        min.segment.length = 0
      ) +
      coord_sf(expand = FALSE) +
      theme_void() +
      theme(
        legend.position = "right",
        legend.title    = element_text(color = "black", size = 12),
        plot.background = element_rect(fill = "white", color = NA)
      )
    
    
    ggsave(
      paste0(
        out_buffer_dir_summary_png,
        "/",
        "LATAM_Edible_food_",
        variable,
        "_",
        quant,
        "_species_richness_current.png"
      ),
      plot = p,
      width = 14,
      height = 14,
      dpi = 300
    )
  }
  
}
return("DONE!")
  }
################################################################################
##############################################################################
#config adding a results_dir
output_dir <- "/catalogue/MultifLandscapesA1706/1.Data/Results"



user <- "Chrystian"
if (user == "Chrystian") {
  basedir <-  "/catalogue/MultifLandscapesA1706"
}

resultdir <-
  "/catalogue/MultifLandscapesA1706/1.Data/Results/SDM results"


species_selected <- as.data.frame(
  readxl::read_xlsx(
    "/catalogue/MultifLandscapesA1706/1.Data/Results/species_lists/species_curated/Species_20250304_edible_part_curated.xlsx",
    col_names = T
  )
)
template_file <-
  paste0(
    "/catalogue/MultifLandscapesA1706/1.Data/RAW/Input_data/climate_data/2_5min/present/",
    "wc2.1_2.5m_bio_1.tif"
  )


data_ori <-
  read.csv(
    "/catalogue/MultifLandscapesA1706/1.Data/Process/soil_extreme/outliers_list.csv"
  )



x <- summmary_raster_quantile(basedir,
           resultdir,
           output_dir,
           species_selected,
           template_file,
           data_ori)