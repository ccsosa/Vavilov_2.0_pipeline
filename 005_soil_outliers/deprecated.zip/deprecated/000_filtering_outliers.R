## Filtering by quantiles

## summary SDM methodology:
# target-group background points
# spatial block cross-validation (blockCV package)
# environmental filtering
# tuning of Maxent parameter settings (ENMeval)

## content script
# part 0: Preparations
# part 1: Preparation of presence data and target group grid
# part 2: Distribution modelling
#install.packages("Rcmdr", dependencies=TRUE) #to install Rcmd
#### PART 0: Preparations ####
# options(Rcmdr.console.output = FALSE)
# library(BiodiversityR, quietly = TRUE)
# options(java.parameters = "-Xmx4g")
# capabilities("tcltk")
# load packages# library(ecospat)
library(data.table)
# library(viridis)
library(sf)
library(terra)
library(dismo)
library(parallel)
library(pbapply)

################################################################################
# set user of the script
user <- "Chrystian"
# user <- "Tobias"

# set base directory
if (user == "Chrystian") {
  basedir <- "/catalogue/MultifLandscapesA1706"
}
if (user == "Tobias") {
  basedir <- "C:/Users/tobia/Dropbox/VAVILOV_2.0"
}
################################################################################
#Defining outcome dir for processing:
temp_dir_eco <- paste0(basedir,
                       "/1.Data/Process/soil_extreme/eco_temp")

if (!dir.exists(temp_dir_eco)) {
  dir.create(temp_dir_eco)
}


################################################################################
#loading template
### soil

soil_vars <-
  paste0(
    basedir,
    "/1.Data/RAW/Input_data/Soil and topography data/30s/",
    c(
      "bdod.tif",
      "cec.tif",
      "cfvo.tif",
      "clay.tif",
      "nitrogen.tif",
      "phh2o.tif",
      "sand.tif",
      "silt.tif",
      "soc.tif"
    )
  )
message("Getting a template for gridSample")

#loading all soil variables
template <- rast(soil_vars[[1]])
template[which(!is.na(template[]))] <- 1

################################################################################
#reading
soil_data <- readRDS(paste0(
  basedir,
  "/1.Data/Process/soil_extreme/",
  "input_data_soil.RDS"
))

# soil_data_filt <- data.frame(dismo::gridSample(soil_data[, c("lon", "lat")], r = raster::stack(template)))


################################################################################
#get species to obtain ecorregions and soil vars

message("Loading soil and biome variables")


specie_unique <-
  read.csv(paste0(
    basedir,
    "/1.Data/Results/SDM results/",
    "species_set_SDM.csv"
  ),
  header = T)
################################################################################

################################################################################
#get unique ecosystems (biomes)

message("Getting biomes")

ecosystems_unique  <- unique(na.omit(soil_data$Biome))
ecosystems_unique <-
  ecosystems_unique[which(ecosystems_unique != "N/A")]

#removing
ecosystems_unique  <- ecosystems_unique[1:12]

################################################################################
#starting with ecosystems and clean up

message("Loading soil and biome variables")

#subsetting by ecosystem
#get unique coords (dummy variable)
################################################################################
#get data per ecosystem

if (!file.exists(paste0(
  basedir,
  "/1.Data/Process/soil_extreme/",
  "soil_extreme_quantile2.csv"
))) {
  
  eco_unique_filtered_data_list <- list()
  
  
  
  numCores <- 12
  cl <- parallel::makeCluster(numCores)
  parallel::clusterExport(cl,
                          varlist = c("ecosystems_unique", "soil_data"),
                          envir = environment())
  
  
  # Load required packages on each cluster node
  parallel::clusterEvalQ(cl, {
    library(dismo)
    library(terra)
  })
  
  
  eco_unique_filtered_data_list <- pblapply(
    X = seq_len(length(ecosystems_unique)),
    FUN = function(i) {
      #eco_unique_filtered_data_list <- list()
      # for (i in 1:length(ecosystems_unique)) {
      
      #i <- 1
      message("Subsetting per ecosystem")
      
      #subsetting by biome
      
      if (!file.exists(paste0(
        basedir,
        "/1.Data/Process/soil_extreme/",
        ecosystems_unique[[i]],
        ".RDS"
      ))) {
        x_i <- subset(soil_data, Biome == ecosystems_unique[[i]])
        x_i$coords <- paste0(x_i$lon, "-", x_i$lat)
        
        #unique species searched
        unique_sp_eco <- unique(x_i$species_searched)
        
        
        message(
          paste0(
            "Subsetting per ecosystem, species and performing gridSample filtering:"
          ),
          ecosystems_unique[[i]]
        )
        eco_unique_filtered_data <- list()
        #per each species
        # sp_i_var_total_j <- list()
        
        
        for (j in 1:length(unique_sp_eco)) {
          #j <- 1
          # print(j)
          #get subset by sp and ecosystem
          x_i_sp <-
            subset(x_i, species_searched == unique_sp_eco[[j]])
          #provide spatial filter using gridSample at 1 km
          TG <-
            data.frame(dismo::gridSample(x_i_sp[, c("lon", "lat")], r = raster::stack(template)))
          TG$coords <- paste0(TG$lon, "-", TG$lat)
          #subset
          TG <- x_i_sp[x_i_sp$coords %in% TG$coords,]
          #removing coords dummy column
          TG$coords <- NULL
          
          #obtaining it
          eco_unique_filtered_data[[j]] <- TG
          
       #    sp_i_var <- list()
       #    for (k in 4:12) {
       #      # k <- 4
       #     TG_q <- quantile(TG[,k],na.rm=TRUE,c(0.05,0.10,0.90,0.95))
       #     data_sp  <- data.frame(
       #      eco = ecosystems_unique[[i]],
       #      sp= unique_sp_eco[[j]],
       #      var = colnames(TG)[[k]],
       #      Q5 = nrow(TG[which(TG[,k]<TG_q[1]),]),
       #      Q10 = nrow(TG[which(TG[,k]<TG_q[2]),]),
       #      Q90 = nrow(TG[which(TG[,k]>TG_q[3]),]),
       #      Q95 = nrow(TG[which(TG[,k]>TG_q[4]),]),
       #      n = nrow(TG)
       #     )
       #     sp_i_var[[k]] <- data_sp
       #    }
       #  sp_i_var <- do.call(rbind,sp_i_var)
       #  sp_i_var_total_j[[j]] <- sp_i_var
       }
       #  sp_i_var_total_j <- do.call(rbind,sp_i_var_total_j)
        # for(i in 1:)
        #rm(TG)
        #getting all ecosystems
        eco_unique_filtered_data <-
          do.call(rbind, eco_unique_filtered_data)
        
        message("Obtaining soil outliers using quantiles Q10,Q90, Q5, Q95")
        
        
        outliers_k <- list()
        for (k in 4:12) {
          # print(k)
          # k <- 4
          #quantile 10-90%
          x_q_10_90 <-
            quantile(eco_unique_filtered_data[, k],
                     probs = c(0.1, 0.9),
                     na.rm = TRUE)
          #quantile 5-95%
          x_q_5_95 <-
            quantile(eco_unique_filtered_data[, k],
                     probs = c(0.05, 0.95),
                     na.rm = TRUE)
          
          #getting final vars
          L10 <- data.frame(
            species = unique(eco_unique_filtered_data$species_searched[which(eco_unique_filtered_data[, k] < x_q_10_90[1])]),
            quantile = "Q10",
            QV = as.numeric(x_q_10_90[1])
          )
          
          
          L90 <- data.frame(
            species = unique(eco_unique_filtered_data$species_searched[which(eco_unique_filtered_data[, k] > x_q_10_90[2])]),
            quantile = "Q90",
            QV = as.numeric(x_q_10_90[2])
          )
          
          L5 <- data.frame(
            species = unique(eco_unique_filtered_data$species_searched[which(eco_unique_filtered_data[, k] < x_q_5_95[1])]),
            quantile = "Q5",
            QV = as.numeric(x_q_5_95[1])
          )
          
          L95 <- data.frame(
            species = unique(eco_unique_filtered_data$species_searched[which(eco_unique_filtered_data[, k] > x_q_5_95[2])]),
            quantile = "Q95",
            QV = as.numeric(x_q_5_95[2])
          )
          
          L <- rbind(L10, L90, L5, L95)
          L$variable <- colnames(eco_unique_filtered_data)[k]
          #how many points of the ecosystem in the quantile
          L$sp_eco_n <- NA
          
          for(l in 1:nrow(L)){
            
          }
          
          outliers_k[[k]] <- L
        }
        outliers_k <- do.call(rbind, outliers_k)
        outliers_k$Ecosystem <- ecosystems_unique[[i]]
        
        #saving intermediate results
        
        saveRDS(outliers_k,
                paste0(temp_dir_eco, "/",
                       ecosystems_unique[[i]], ".RDS"))
        
        # eco_unique_filtered_data_list[[i]] <- outliers_k
        outliers_k
      } else {
        outliers_k <- readRDS(paste0(temp_dir_eco, "/",
                                     ecosystems_unique[[i]], ".RDS"))
        
        # outliers_k
        
      }
      
      #}
      
      #eco_unique_filtered_data_list <- do.call(rbind,eco_unique_filtered_data_list)
      
    })
  
  parallel::stopCluster(cl)
  
  eco_unique_filtered_data_list <-
    do.call(rbind, eco_unique_filtered_data_list)
  
  #saving
  
  message("Saving as a CSV file")
  
  
  write.csv(
    eco_unique_filtered_data_list,
    paste0(
      basedir,
      "/1.Data/Process/soil_extreme/",
      "soil_extreme_quantile2.csv"
    ),
    na = "",
    row.names = F
  )
  
} else {
  eco_unique_filtered_data_list <-
    read.csv(paste0(
      basedir,
      "/1.Data/Process/soil_extreme/",
      "soil_extreme_quantile2.csv"
    ))
}

################################################################################

summary_list <- list()
for (i in 1:length(ecosystems_unique)) {
  #i <- 1
  #Ecosystem subset
  x_i <-
    eco_unique_filtered_data_list[which(eco_unique_filtered_data_list$Ecosystem ==
                                          ecosystems_unique[[i]]), ]
  #unique variables
  var_un <- unique(x_i$variable)
  
  
  df_j <- list()
  #per each variable
  for (j in 1:length(var_un)) {
    #j <- 1
    #variable subset
    x_j <- x_i[which(x_i$variable == var_un[[j]]), ]
    #quantile speces
    x_j_Q10 <- x_j[which(x_j$quantile == "Q10"), ]
    x_j_Q90 <- x_j[which(x_j$quantile == "Q90"), ]
    x_j_Q5 <- x_j[which(x_j$quantile == "Q5"), ]
    x_j_Q95 <- x_j[which(x_j$quantile == "Q95"), ]
    
    #summary (length of unique species)
    df_j[[j]] <- data.frame(
      eco = ecosystems_unique[[i]],
      var = var_un[[j]],
      Q10_sp = length(unique(x_j_Q10$species)),
      Q90_sp = length(unique(x_j_Q90$species)),
      Q5_sp = length(unique(x_j_Q5$species)),
      Q95_sp = length(unique(x_j_Q95$species))
    )
  }
  df_j <- do.call(rbind, df_j)
  summary_list[[i]] <- df_j
}

summary_list <- do.call(rbind, summary_list)
rm(df_j,x_i,x_j,x_j_Q10,x_j_Q5,x_j_Q90,x_j_Q95,i,j);gc()
#save
write.csv(
  summary_list,
  paste0(
    basedir,
    "/1.Data/Process/soil_extreme/",
    "summary_outlier_sp.csv"
  ),
  na = "",
  row.names = F
)

################################################################################
#detect species in all the variables
#defining quantiles
quantiles  <- c("Q10","Q90","Q5","Q95")

quant_df <- list()
for(i in 1:length(quantiles)){
  # i <- 1
  #subset for each of the ecosystems per quantiles
  eco_i <- eco_unique_filtered_data_list[which(eco_unique_filtered_data_list$quantile==quantiles[[i]]),]
  
  eco_j_df <- list()
  for(j in 1:length(ecosystems_unique)){
    # j <- 1
    #per ecosystem
    eco_i_eco <- eco_i[which(eco_i$Ecosystem == ecosystems_unique[[j]]),] 
    
    sp_k_vars_df <- list()
    for(k in 1:length(specie_unique$x)){
      # k <- 1
      #subsetting per specie
      eco_i_sp_k <- eco_i_eco$variable[which(eco_i_eco$species==specie_unique$x[[k]])]
      
      #joining df
      df <- data.frame(species = specie_unique$x[[k]],
                       ecosystem = ecosystems_unique[[j]],
                       variables = paste(eco_i_sp_k,collapse = "/"),
                       vars_n = length(eco_i_sp_k),
                       quantile = quantiles[[i]]
      )
      
      sp_k_vars_df[[k]] <- df;rm(df)
    };rm(k)
    
    sp_k_vars_df <- do.call(rbind,sp_k_vars_df)
    eco_j_df[[j]] <- sp_k_vars_df
  }
  
  eco_j_df <- do.call(rbind,eco_j_df)
  quant_df[[i]] <- eco_j_df
}

quant_df <- do.call(rbind,quant_df)
#removing species with less than five vars
quant_df <- quant_df[which(quant_df$vars_n>4),]


#save
write.csv(
  quant_df,
  paste0(
    basedir,
    "/1.Data/Process/soil_extreme/",
    "final_VACS_list.csv"
  ),
  na = "",
  row.names = F
)

length(unique(quant_df$species))
################################################################################
#per 