## Distribution modelling script for D4R cacao

## summary SDM methodology:
# target-group background points
# spatial block cross-validation (blockCV package)
# environmental filtering
# tuning of Maxent parameter settings (ENMeval)

## content script
# part 0: Preparations
# part 1: Preparation of presence data and target group grid
# part 2: Distribution modelling

#### PART 0: Preparations ####
options(java.parameters = "-Xmx4g")

# load packages
library(raster)
library(dismo)
library(rgeos)
library(rgdal)
library(blockCV)
library(rJava)
library(ENMeval)
# library(ecospat)
library(data.table)
library(viridis)
library(sf)
library(terra)
library(usdm)
library(pROC)
library(parallel)
################################################################################
# set user of the script
user <- "Chrystian"
# user <- "Tobias"

# set base directory
if (user == "Chrystian") {
  basedir <- "/catalogue/MultifLandscapesA1706"
}
if (user == "Tobias") {
  basedir <- "C:/Users/tobia/Dropbox/VAVILOV_2.0"
}

################################################################################
# set output directories
outputdir <- paste0(basedir, "/1.Data/Results/SDM results")
spListDir <-
  paste0(basedir, "/1.Data/Results/buffer_richness/summary")

################################################################################
### soil
soil_vars <-
  paste0(
    basedir,
    "/1.Data/RAW/Input_data/Soil and topography data/2_5min/",
    c(
      "bdod.tif",
      "cec.tif",
      "cfvo.tif",
      "clay.tif",
      "nitrogen.tif",
      "phh2o.tif",
      "sand.tif",
      "silt.tif",
      "soc.tif"
    )
  )
#loading all soil variables
soil_vars <- lapply(1:length(soil_vars), function(i) {
  x <- terra::rast(soil_vars[[i]])
  return(x)
})


soil_vars <- terra::rast(soil_vars)
################################################################################
#ecorregions loading
message("Loading ecorregions")

if (file.exists(paste0(
  basedir,
  "/1.Data/RAW/Input_data/Ecoregions/Ecoregions2017.gpkg"
))) {
  message("Loading ecorregions previously fixed!")
  eco <-
    sf::st_read(paste0(
      basedir,
      "/1.Data/RAW/Input_data/Ecoregions/Ecoregions2017.gpkg"
    ))
  
} else {
  sf_use_s2(FALSE)  # Desactivar s2 para la reparación
  eco <-
    sf::st_read(paste0(
      basedir,
      "/1.Data/RAW/Input_data/Ecoregions/Ecoregions2017.shp"
    )) #terra::vect
  eco_fix <- st_make_valid(eco)
  sf::write_sf(
    eco_fix,
    paste0(
      basedir,
      "/1.Data/RAW/Input_data/Ecoregions/Ecoregions2017.gpkg"
    )
  )
  eco <- eco_fix
}
################################################################################
# load presence points

message("loading species list")

sp_list <- readxl::read_xlsx("/catalogue/MultifLandscapesA1706/1.Data/Results/species_lists/species_curated/Species_20250304_edible_part_curated.xlsx")
sp_list_to <- unique(sp_list$species)

message("Loading occurrences")

setwd(dir = paste0(basedir, "/1.Data/RAW/occurrences/cleaned"))

if(!file.exists(paste0(basedir, "/1.Data/RAW/occurrences/cleaned/GBIF_joined_FINAL_20260317_spList_filtered.csv"))){
  # p1 <- read.csv("GBIF_joined_FINAL_3.csv")
  p1 <- read.csv("GBIF_joined_FINAL_3.csv")
  # p1 <- p1[which(p1$species_searched %in% sp_list_to),]
  length(unique(p1$species_searched))
  p1_plus <- read.csv("GBIF_data_third_round_cleaned_FINAL_2.csv")
  # p1_plus <- p1_plus[which(p1_plus$species_searched %in% sp_list_to),]
  length(unique(p1_plus$species_searched))
  
  
  p1 <- p1[,c("species","species_searched","country","year","adm1","locality","collection_code",
              "dataset_name","dataset_key","institution_code","source","lon","lat","coords")]
  
  p1_plus <- p1_plus[,c("species","species_searched","country","year","adm1","locality","collection_code",
                        "dataset_name","dataset_key","institution_code","source","lon","lat","coords")]
  uniq_file <- rbind(p1,p1_plus)
  
  p1 <- uniq_file[which(uniq_file$species_searched %in% sp_list_to),]
  write.csv(uniq_file,paste0("./", "GBIF_joined_FINAL_20260317.csv"))
  write.csv(p1,paste0("./", "GBIF_joined_FINAL_20260317_spList_filtered.csv"))
  length(unique(p1$species_searched))
} else {
  p1 <- read.csv(paste0(basedir, "/1.Data/RAW/occurrences/cleaned/GBIF_joined_FINAL_20260317_spList_filtered.csv"),header = T)
}


################################################################################
#get species to obtain ecorregions and soil vars
# specie_unique <-
#   read.csv(paste0(
#     basedir,
#     "/1.Data/Results/SDM results/",
#     "species_set_SDM.csv"
#   ),
#   header = T)
################################################################################
message("Getting ecorregions and soil information")

soil_p_i <- lapply(1:length(sp_list_to), function(i) {
  #soil_p_i <- lapply(1:3, function(i) {
  message(paste0("i: ",i," / ",length(sp_list_to)))
  # i <- 1
  #get by species and ecosystems
  p1_sp <- p1[which(p1$species_searched == sp_list_to[[i]]), ]
  
  #guaranting only using species with info
  if (nrow(p1_sp) > 0) {
    
    #extracting soil vars
    p2 <- terra::extract(soil_vars, cbind(p1_sp$lon, p1_sp$lat))
    p2 <- cbind(p1_sp[, c("species_searched", "lon", "lat")], p2)
    
    #get points with ecorregions (FAST)
    points <-
      sf::st_as_sf(p1_sp,
                   coords = c("lon", "lat"),
                   crs = st_crs(eco))
    points_with_ecoregion <-
      sf::st_join(x = points, y = eco, join = st_intersects)
    
    p2 <-
      cbind(p2,
            points_with_ecoregion$ECO_NAME,
            points_with_ecoregion$BIOME_NAME)
    colnames(p2)[c(13, 14)] <- c("Ecorregion", "Biome")
    
  } else {
    
    p2 <- NULL
    
  }
  return(p2)
})
################################################################################
#Joining all species in one fie

soil_p_i_2 <- do.call(rbind, soil_p_i)

message("saving results (soil + ecorregions)")

#saving
saveRDS(                  
  soil_p_i_2,
  paste0(
    basedir,
    "/1.Data/Process/soil_extreme/",
    "input_data_soil_20260317.RDS"
  )
)
################################################################################